import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { Trip } from '../types';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/States';
import {
  formatDate,
  formatDistance,
  formatDuration,
  formatTime,
  toMonthStr,
  formatMonth,
  getDaysInMonth,
} from '../utils';
import {
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  Navigation2,
  MapPin,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function HistoryScreen() {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'calendar' | 'list'>('calendar');

  const month = toMonthStr(currentDate);

  useEffect(() => {
    if (!token) return;
    setLoading(true);
    api.trips.list(token, month)
      .then(setTrips)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [token, month]);

  const prevMonth = () => {
    const d = new Date(currentDate);
    d.setMonth(d.getMonth() - 1);
    setCurrentDate(d);
  };
  const nextMonth = () => {
    const d = new Date(currentDate);
    d.setMonth(d.getMonth() + 1);
    if (d > new Date()) return;
    setCurrentDate(d);
  };

  const days = getDaysInMonth(currentDate.getFullYear(), currentDate.getMonth());
  const tripDays = new Set(trips.map(t => new Date(t.started_at).toDateString()));

  const monthTotal = {
    distance: trips.reduce((a, t) => a + t.distance_m, 0),
    duration: trips.reduce((a, t) => a + t.duration_s, 0),
    count: trips.length,
  };

  return (
    <div className="h-full flex flex-col bg-slate-50">
      {/* APP BAR */}
      <div className="bg-white/95 backdrop-blur-md px-4 pt-12 pb-4 border-b border-slate-200/80 sticky top-0 z-20">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight">Trip History</h1>
            <p className="text-xs text-slate-500 font-medium">Logged routes &amp; telemetry</p>
          </div>
          <div className="flex gap-1 bg-slate-100 p-1 rounded-2xl">
            <button
              onClick={() => setView('calendar')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                view === 'calendar' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
              }`}
            >
              Calendar
            </button>
            <button
              onClick={() => setView('list')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                view === 'list' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
              }`}
            >
              List
            </button>
          </div>
        </div>

        {/* Month Selector Strip */}
        <div className="flex items-center justify-between bg-slate-50 border border-slate-100 rounded-2xl px-2 py-1">
          <button
            onClick={prevMonth}
            className="p-2 rounded-xl text-slate-600 hover:bg-white active:scale-95 transition-all"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <h2 className="text-xs font-black text-slate-900 uppercase tracking-wider">{formatMonth(month)}</h2>
          <button
            onClick={nextMonth}
            disabled={toMonthStr(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1)) > toMonthStr(new Date())}
            className="p-2 rounded-xl text-slate-600 hover:bg-white disabled:opacity-20 active:scale-95 transition-all"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-24">
        {loading ? (
          <LoadingSpinner message="Calculating trip history..." />
        ) : error ? (
          <ErrorBanner message={error} />
        ) : (
          <>
            {/* MONTHLY TOTALS METRICS */}
            <div className="px-4 mt-4 grid grid-cols-3 gap-2.5">
              <div className="bg-white border border-slate-100 rounded-2xl p-3 text-center shadow-sm">
                <p className="text-lg font-black text-slate-900 font-mono">{monthTotal.count}</p>
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Total Trips</p>
              </div>
              <div className="bg-white border border-slate-100 rounded-2xl p-3 text-center shadow-sm">
                <p className="text-lg font-black text-blue-600 font-mono">{formatDistance(monthTotal.distance)}</p>
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Distance</p>
              </div>
              <div className="bg-white border border-slate-100 rounded-2xl p-3 text-center shadow-sm">
                <p className="text-lg font-black text-slate-900 font-mono">{formatDuration(monthTotal.duration)}</p>
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Drive Time</p>
              </div>
            </div>

            {/* CALENDAR VIEW */}
            {view === 'calendar' && (
              <div className="mx-4 mt-4 bg-white border border-slate-100 rounded-3xl p-3.5 shadow-sm">
                <div className="grid grid-cols-7 border-b border-slate-100 pb-2 mb-2">
                  {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
                    <div key={i} className="text-center text-[11px] font-bold text-slate-400">{d}</div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-y-1.5">
                  {Array.from({ length: days[0].getDay() }).map((_, i) => (
                    <div key={`empty-${i}`} className="h-10" />
                  ))}
                  {days.map(day => {
                    const hasTrip = tripDays.has(day.toDateString());
                    const isToday = day.toDateString() === new Date().toDateString();
                    const dayTrips = trips.filter(t => new Date(t.started_at).toDateString() === day.toDateString());
                    return (
                      <button
                        key={day.toISOString()}
                        onClick={() => hasTrip && setView('list')}
                        className="h-10 flex flex-col items-center justify-center rounded-2xl transition-colors hover:bg-slate-50"
                      >
                        <span className={`text-xs font-bold w-6 h-6 flex items-center justify-center rounded-full ${
                          isToday ? 'bg-blue-600 text-white shadow-sm' : hasTrip ? 'text-slate-900' : 'text-slate-400 font-normal'
                        }`}>
                          {day.getDate()}
                        </span>
                        {hasTrip && (
                          <div className="flex gap-0.5 mt-0.5">
                            {dayTrips.slice(0, 3).map((_, i) => (
                              <span key={i} className="w-1 h-1 bg-blue-500 rounded-full" />
                            ))}
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TRIP TIMELINE CARDS */}
            <div className="px-4 mt-4 space-y-3">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  {view === 'calendar' ? 'Recorded Trips' : 'All Month Trips'}
                </h3>
                <span className="text-xs text-slate-400 font-semibold">{trips.length} entries</span>
              </div>

              {trips.length === 0 ? (
                <EmptyState
                  icon={<CalendarDays className="w-12 h-12" />}
                  title="No trips recorded"
                  description="Start a new trip on the Live Map to track your routes and mileage."
                />
              ) : (
                trips.map(trip => (
                  <button
                    key={trip.id}
                    onClick={() => navigate(`/trips/${trip.id}`)}
                    className="w-full bg-white border border-slate-100 rounded-3xl p-4 shadow-sm hover:shadow-md text-left transition-all active:scale-[0.99] flex flex-col gap-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 bg-blue-50 text-blue-700 font-bold rounded-xl text-xs">
                          {formatDate(trip.started_at)}
                        </span>
                        <span className="text-xs text-slate-400 font-medium">
                          {formatTime(trip.started_at)}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-xs font-bold text-blue-600 font-mono">
                        <Navigation2 className="w-3.5 h-3.5" />
                        {formatDistance(trip.distance_m)}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-700">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate font-medium">{trip.start_address || 'Origin'}</span>
                      <ArrowRight className="w-3 h-3 text-slate-300 shrink-0" />
                      <span className="truncate font-medium text-slate-900">{trip.end_address || 'Destination'}</span>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-50 text-[11px] text-slate-400 font-medium">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Duration: {formatDuration(trip.duration_s)}
                      </span>
                      <span className="text-blue-600 font-semibold flex items-center gap-0.5">
                        Details <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </button>
                ))
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

import { useState, useEffect, useRef } from 'react';
import { useNavigation } from '../hooks/useNavigation';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { Map, CalendarDays, Users, Settings, ClipboardList } from 'lucide-react';

// Tiny inline beep sound (base64 WAV — short notification tone)
const BEEP_MP3 = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2YWBhRimNPStGAMBA1Xh7m0mVkWFh9mjsXDsXkiFypxp9LRq3IiHiVulNLNpnQmHypytNbTqXQkICl2r9jXqHQmHi50s9bUqXUkHit4s9jWqHYmIi95tNfWqXYkHyt5tNfWp3ckIC55s9bVqXckIC55s9bUqHUlIS96s9jWqHUlIS95s9bVqHUmIjB6s9jVqHQmIzF7s9jVqHQnIzF7tNnWqHQnIzF7s9jWqXUnIzF7s9jWqHQnIzF7tNnWqXUnJDJ8tNnWqXQnJDJ8s9jWqXQnJDJ8tNnWqXQnIzF8s9jWqXQnIzF8s9jWqXQnIzF8s9jWqHQnIzF8s9jWqXQnIzF8s9jWqHQnIzJ8s9jWqXQnIzF8s9jWqXQnIzF8s9jWqHQnIzF8s9jWqHQnIzF8s9jWqXQnIzF8s9jWqHQnIzF8s9jWqHQ=';

function playNotificationSound() {
  try {
    const audio = new Audio(BEEP_MP3);
    audio.volume = 0.6;
    audio.play().catch(() => {});
  } catch {}
}

export function BottomNav() {
  const { user, token } = useAuth();
  const { navigate, currentPath } = useNavigation();
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifCount, setNotifCount] = useState(0);
  const prevNotifCountRef = useRef(0);

  // Poll unread comments (for member badge on Daily tab)
  useEffect(() => {
    if (!token) return;

    const checkUnread = () => {
      api.daily.unreadCount(token)
        .then(res => setUnreadCount(res.count || 0))
        .catch(() => {});
    };

    checkUnread();
    const interval = setInterval(checkUnread, 15000);
    return () => clearInterval(interval);
  }, [token, currentPath]);

  // Poll notifications for manager (sound alert when new teammate submission arrives)
  useEffect(() => {
    if (!token || user?.role !== 'manager') return;

    const checkNotifications = () => {
      api.daily.getNotifications(token)
        .then(notifs => {
          const count = notifs.length;
          setNotifCount(count);
          // Play sound if new unseen notifications arrived since last check
          if (count > prevNotifCountRef.current) {
            playNotificationSound();
            // Show browser notification if permission granted
            if ('Notification' in window && Notification.permission === 'granted' && notifs.length > 0) {
              const latest = notifs[0];
              new Notification(`📊 ${latest.from_user_name} submitted report`, {
                body: latest.summary,
                icon: '/icon.svg',
                tag: `notif-${latest.id}`,
              });
            }
          }
          prevNotifCountRef.current = count;
        })
        .catch(() => {});
    };

    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }

    checkNotifications();
    const interval = setInterval(checkNotifications, 20000);
    return () => clearInterval(interval);
  }, [token, user?.role]);

  const memberTabs = [
    { path: '/', icon: Map, label: 'Live Map', badge: 0 },
    { path: '/daily', icon: ClipboardList, label: 'Daily', badge: unreadCount },
    { path: '/history', icon: CalendarDays, label: 'Trips', badge: 0 },
    { path: '/settings', icon: Settings, label: 'Settings', badge: 0 },
  ];

  const managerTabs = [
    { path: '/', icon: Map, label: 'Radar', badge: 0 },
    { path: '/daily', icon: ClipboardList, label: 'Daily', badge: notifCount + unreadCount },
    { path: '/history', icon: CalendarDays, label: 'Trips', badge: 0 },
    { path: '/team', icon: Users, label: 'Members', badge: 0 },
    { path: '/settings', icon: Settings, label: 'Settings', badge: 0 },
  ];

  const tabs = user?.role === 'manager' ? managerTabs : memberTabs;

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-40">
      <div className="glass-dock px-2 pt-2 pb-safe shadow-2xl border-t border-slate-200/80">
        <div className="flex items-center justify-around">
          {tabs.map(({ path, icon: Icon, label, badge }) => {
            const active = currentPath === path || (path !== '/' && currentPath.startsWith(path));
            const hasBadge = (badge ?? 0) > 0;
            return (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={`relative flex flex-col items-center py-1 px-2 rounded-2xl transition-all duration-200 active:scale-95 ${
                  active
                    ? 'text-blue-600 font-bold'
                    : 'text-slate-400 hover:text-slate-600 font-medium'
                }`}
              >
                <div className={`p-1.5 rounded-xl transition-colors relative ${active ? 'bg-blue-50 text-blue-600' : ''}`}>
                  <Icon className="w-5 h-5" strokeWidth={active ? 2.4 : 1.8} />
                  {hasBadge && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white rounded-full text-[9px] font-black flex items-center justify-center shadow animate-bounce">
                      {badge > 9 ? '9+' : badge}
                    </span>
                  )}
                </div>
                <span className="text-[10px] tracking-tight mt-0.5">{label}</span>
                {active && (
                  <span className="absolute bottom-0 w-1.5 h-1.5 bg-blue-600 rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

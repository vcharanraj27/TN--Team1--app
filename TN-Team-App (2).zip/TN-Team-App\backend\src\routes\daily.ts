import { Router, Request, Response } from 'express';
import { dbAll, dbGet, dbRun } from '../database';
import { authenticate, requireManager } from '../middleware/auth';
import { randomUUID } from 'crypto';

const router = Router();
router.use(authenticate);

// Helper: get today's date in YYYY-MM-DD format
function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

// Helper: get current month string YYYY-MM
function currentMonthStr(): string {
  return new Date().toISOString().slice(0, 7);
}

// Helper: check monthly target window (1st to 7th of every month)
function getMonthlyTargetWindow() {
  const now = new Date();
  const dayOfMonth = now.getDate(); // 1 to 31
  const isOpen = dayOfMonth >= 1 && dayOfMonth <= 7;
  const daysRemaining = isOpen ? 7 - dayOfMonth + 1 : 0;
  return {
    isOpen,
    dayOfMonth,
    daysRemaining,
    currentMonth: currentMonthStr(),
    windowMessage: isOpen
      ? `Monthly target window is OPEN (1st to 7th). ${daysRemaining} day(s) remaining to set targets for this month.`
      : `Monthly target window is CLOSED. Targets can only be set from the 1st to 7th of the month.`,
  };
}

// GET /api/daily?date=YYYY-MM-DD — Get user's daily entry for a specific date (defaults to today)
router.get('/', (req: Request, res: Response) => {
  const { userId } = req.user!;
  const date = (req.query.date as string) || todayStr();

  const entry = dbGet(
    `SELECT * FROM daily_entries WHERE user_id = ? AND entry_date = ?`,
    [userId, date]
  );

  res.json(
    entry || {
      sales_amount: 0,
      collection_amount: 0,
      activity_count: 0,
      new_pd_count: 0,
      target_sales: 0,
      target_collection: 0,
      target_activity: 0,
      target_new_pd: 0,
      notes: '',
      entry_date: date,
    }
  );
});

// Helper: check if daily target entry is still allowed (before 10:30 AM IST)
function isDailyTargetWindowOpen(): boolean {
  // IST = UTC+5:30
  const now = new Date();
  const istOffsetMs = 5.5 * 60 * 60 * 1000;
  const istNow = new Date(now.getTime() + istOffsetMs);
  const hours = istNow.getUTCHours();
  const minutes = istNow.getUTCMinutes();
  // window open if before 10:30 AM IST
  return hours < 10 || (hours === 10 && minutes < 30);
}

// POST /api/daily — Create or update daily entry (actuals & daily targets) for today
router.post('/', (req: Request, res: Response) => {
  const { userId, teamId, role } = req.user!;
  const {
    sales_amount,
    collection_amount,
    activity_count,
    new_pd_count,
    target_sales,
    target_collection,
    target_activity,
    target_new_pd,
    notes,
  } = req.body;
  const date = todayStr();

  // Check if any target fields are being submitted
  const hasTargetFields =
    target_sales !== undefined ||
    target_collection !== undefined ||
    target_activity !== undefined ||
    target_new_pd !== undefined;

  const existing = dbGet<{ id: string; target_submitted_at: string | null }>(
    `SELECT id, target_submitted_at FROM daily_entries WHERE user_id = ? AND entry_date = ?`,
    [userId, date]
  );

  // Enforce 10:30 AM IST lock for daily targets (for members only)
  if (hasTargetFields && role === 'member') {
    if (existing?.target_submitted_at) {
      res.status(403).json({
        error: 'Daily target has already been submitted for today. You can only set it once per day.',
        targetLocked: true,
      });
      return;
    }
    if (!isDailyTargetWindowOpen()) {
      res.status(403).json({
        error: 'Daily target entry window is closed. Targets can only be set before 10:30 AM IST.',
        targetLocked: true,
        windowClosed: true,
      });
      return;
    }
  }

  const now = new Date().toISOString();
  const targetSubmittedAt = hasTargetFields ? now : (existing?.target_submitted_at || null);

  let entryId: string;

  if (existing) {
    // Build update: if target fields are NOT being set, preserve old target values
    if (hasTargetFields) {
      dbRun(
        `UPDATE daily_entries SET
          sales_amount = ?,
          collection_amount = ?,
          activity_count = ?,
          new_pd_count = ?,
          target_sales = ?,
          target_collection = ?,
          target_activity = ?,
          target_new_pd = ?,
          target_submitted_at = ?,
          notes = ?,
          updated_at = datetime('now')
         WHERE id = ?`,
        [
          sales_amount ?? 0,
          collection_amount ?? 0,
          activity_count ?? 0,
          new_pd_count ?? 0,
          target_sales ?? 0,
          target_collection ?? 0,
          target_activity ?? 0,
          target_new_pd ?? 0,
          targetSubmittedAt,
          notes || '',
          existing.id,
        ]
      );
    } else {
      dbRun(
        `UPDATE daily_entries SET
          sales_amount = ?,
          collection_amount = ?,
          activity_count = ?,
          new_pd_count = ?,
          notes = ?,
          updated_at = datetime('now')
         WHERE id = ?`,
        [
          sales_amount ?? 0,
          collection_amount ?? 0,
          activity_count ?? 0,
          new_pd_count ?? 0,
          notes || '',
          existing.id,
        ]
      );
    }
    entryId = existing.id;
  } else {
    entryId = randomUUID();
    dbRun(
      `INSERT INTO daily_entries (
        id, user_id, team_id, entry_date,
        sales_amount, collection_amount, activity_count, new_pd_count,
        target_sales, target_collection, target_activity, target_new_pd,
        target_submitted_at, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        entryId,
        userId,
        teamId,
        date,
        sales_amount ?? 0,
        collection_amount ?? 0,
        activity_count ?? 0,
        new_pd_count ?? 0,
        target_sales ?? 0,
        target_collection ?? 0,
        target_activity ?? 0,
        target_new_pd ?? 0,
        targetSubmittedAt,
        notes || '',
      ]
    );
  }

  // Insert notification for manager (only for member submissions, deduplicate by user+date)
  if (role === 'member') {
    const submitter = dbGet<{ name: string }>(`SELECT name FROM users WHERE id = ?`, [userId]);
    const summaryParts: string[] = [];
    if (sales_amount !== undefined) summaryParts.push(`Sales: ₹${sales_amount || 0}`);
    if (collection_amount !== undefined) summaryParts.push(`Collection: ₹${collection_amount || 0}`);
    if (activity_count !== undefined) summaryParts.push(`Farmer's Visit/Meating: ${activity_count || 0}`);
    if (new_pd_count !== undefined) summaryParts.push(`New PD: ${new_pd_count || 0}`);
    const summary = summaryParts.length > 0 ? summaryParts.join(', ') : 'Updated daily entry';

    // Delete old notification for this user+date to avoid duplicates, then insert fresh
    dbRun(`DELETE FROM notifications WHERE from_user_id = ? AND created_at LIKE ?`, [userId, `${date}%`]);
    const notifId = randomUUID();
    dbRun(
      `INSERT INTO notifications (id, team_id, from_user_id, from_user_name, type, summary, is_seen)
       VALUES (?, ?, ?, ?, 'daily_entry', ?, 0)`,
      [notifId, teamId, userId, submitter?.name || 'Teammate', summary]
    );
  }

  const entry = dbGet(`SELECT * FROM daily_entries WHERE id = ?`, [entryId]);
  res.json(entry);
});


// GET /api/daily/monthly-target?month=YYYY-MM — Get monthly target and window status
router.get('/monthly-target', (req: Request, res: Response) => {
  const { userId } = req.user!;
  const month = (req.query.month as string) || currentMonthStr();
  const windowInfo = getMonthlyTargetWindow();

  const target = dbGet(
    `SELECT * FROM monthly_targets WHERE user_id = ? AND target_month = ?`,
    [userId, month]
  );

  res.json({
    target: target || null,
    targetWindow: {
      ...windowInfo,
      isSet: !!target,
      canSet: windowInfo.isOpen && !target,
    },
  });
});

// POST /api/daily/monthly-target — Set monthly target (only 1st to 7th, one time per month)
router.post('/monthly-target', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const { target_sales, target_collection, target_activity, target_new_pd, month } = req.body;
  const targetMonth = month || currentMonthStr();
  const windowInfo = getMonthlyTargetWindow();

  // Enforce 1st to 7th rule
  if (!windowInfo.isOpen) {
    res.status(403).json({
      error: `Monthly target can only be set from the 1st to 7th of every month. The window for ${targetMonth} is closed (today is day ${windowInfo.dayOfMonth}).`,
    });
    return;
  }

  // Check if target already exists for this month (only set once per month)
  const existing = dbGet(
    `SELECT id FROM monthly_targets WHERE user_id = ? AND target_month = ?`,
    [userId, targetMonth]
  );

  if (existing) {
    res.status(400).json({
      error: `Monthly target for ${targetMonth} has already been set and locked for this month.`,
    });
    return;
  }

  const id = randomUUID();
  dbRun(
    `INSERT INTO monthly_targets (
      id, user_id, team_id, target_month,
      target_sales, target_collection, target_activity, target_new_pd,
      is_locked
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`,
    [
      id,
      userId,
      teamId,
      targetMonth,
      target_sales ?? 0,
      target_collection ?? 0,
      target_activity ?? 0,
      target_new_pd ?? 0,
    ]
  );

  const saved = dbGet(`SELECT * FROM monthly_targets WHERE id = ?`, [id]);
  res.json({
    success: true,
    target: saved,
    message: `Monthly target for ${targetMonth} saved and locked successfully.`,
  });
});

// GET /api/daily/mtd — Get month-to-date summary for current user
router.get('/mtd', (req: Request, res: Response) => {
  const { userId } = req.user!;
  const now = new Date();
  const monthStart = now.toISOString().slice(0, 7) + '-01'; // YYYY-MM-01
  const today = todayStr();
  const targetMonth = currentMonthStr();
  const windowInfo = getMonthlyTargetWindow();

  const summary = dbGet<{
    total_sales: number;
    total_collection: number;
    total_activity: number;
    total_new_pd: number;
    total_target_sales: number;
    total_target_collection: number;
    total_target_activity: number;
    total_target_new_pd: number;
    days_entered: number;
  }>(
    `SELECT 
      COALESCE(SUM(sales_amount), 0) as total_sales,
      COALESCE(SUM(collection_amount), 0) as total_collection,
      COALESCE(SUM(activity_count), 0) as total_activity,
      COALESCE(SUM(new_pd_count), 0) as total_new_pd,
      COALESCE(SUM(target_sales), 0) as total_target_sales,
      COALESCE(SUM(target_collection), 0) as total_target_collection,
      COALESCE(SUM(target_activity), 0) as total_target_activity,
      COALESCE(SUM(target_new_pd), 0) as total_target_new_pd,
      COUNT(*) as days_entered
    FROM daily_entries 
    WHERE user_id = ? AND entry_date >= ? AND entry_date <= ?`,
    [userId, monthStart, today]
  );

  // Get monthly target for this month
  const monthlyTarget = dbGet(
    `SELECT * FROM monthly_targets WHERE user_id = ? AND target_month = ?`,
    [userId, targetMonth]
  );

  // Daily history for the month
  const dailyHistory = dbAll(
    `SELECT entry_date, sales_amount, collection_amount, activity_count, new_pd_count,
            target_sales, target_collection, target_activity, target_new_pd,
            notes, updated_at
     FROM daily_entries 
     WHERE user_id = ? AND entry_date >= ? AND entry_date <= ?
     ORDER BY entry_date DESC`,
    [userId, monthStart, today]
  );

  res.json({
    summary,
    monthlyTarget: monthlyTarget || null,
    targetWindow: {
      ...windowInfo,
      isSet: !!monthlyTarget,
      canSet: windowInfo.isOpen && !monthlyTarget,
    },
    dailyHistory,
    monthStart,
    today,
  });
});

// GET /api/daily/comments — Get comments/replies for current user
router.get('/comments', (req: Request, res: Response) => {
  const { userId } = req.user!;

  const comments = dbAll(
    `SELECT mc.id, mc.comment, mc.entry_date, mc.created_at, mc.is_read,
            COALESCE(mc.sender_name, u_sender.name, 'Manager') as sender_name,
            COALESCE(mc.sender_role, 'manager') as sender_role,
            COALESCE(mc.sender_id, mc.manager_id) as sender_id,
            u_mgr.name as manager_name
     FROM manager_comments mc
     LEFT JOIN users u_sender ON u_sender.id = mc.sender_id
     LEFT JOIN users u_mgr ON u_mgr.id = mc.manager_id
     WHERE mc.member_id = ?
     ORDER BY mc.created_at ASC
     LIMIT 100`,
    [userId]
  );

  res.json(comments);
});

// POST /api/daily/reply — Teammate replies to manager comments
router.post('/reply', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const { comment, entryDate } = req.body;

  if (!comment || !comment.trim()) {
    res.status(400).json({ error: 'Reply text cannot be empty' });
    return;
  }

  const user = dbGet<{ name: string; role: string }>(`SELECT name, role FROM users WHERE id = ?`, [userId]);
  const manager = dbGet<{ id: string }>(`SELECT id FROM users WHERE team_id = ? AND role = 'manager' LIMIT 1`, [teamId]);
  const managerId = manager ? manager.id : userId;

  const id = randomUUID();
  dbRun(
    `INSERT INTO manager_comments (id, manager_id, member_id, team_id, sender_id, sender_name, sender_role, comment, entry_date, is_read)
     VALUES (?, ?, ?, ?, ?, ?, 'member', ?, ?, 0)`,
    [id, managerId, userId, teamId, userId, user?.name || 'Teammate', comment.trim(), entryDate || todayStr()]
  );

  const saved = dbGet(
    `SELECT mc.id, mc.comment, mc.entry_date, mc.created_at, mc.is_read,
            COALESCE(mc.sender_name, 'Teammate') as sender_name,
            COALESCE(mc.sender_role, 'member') as sender_role,
            mc.sender_id
     FROM manager_comments mc WHERE mc.id = ?`,
    [id]
  );
  res.json(saved);
});

// POST /api/daily/comments/mark-read — Mark comments as read for user
router.post('/comments/mark-read', (req: Request, res: Response) => {
  const { userId, role, teamId } = req.user!;
  if (role === 'member') {
    dbRun(`UPDATE manager_comments SET is_read = 1 WHERE member_id = ? AND sender_role = 'manager'`, [userId]);
  } else {
    dbRun(`UPDATE manager_comments SET is_read = 1 WHERE team_id = ? AND sender_role = 'member'`, [teamId]);
  }
  res.json({ success: true });
});

// GET /api/daily/comments/unread-count — Unread comments/replies count
router.get('/comments/unread-count', (req: Request, res: Response) => {
  const { userId, role, teamId } = req.user!;
  if (role === 'member') {
    const row = dbGet<{ count: number }>(
      `SELECT COUNT(*) as count FROM manager_comments WHERE member_id = ? AND sender_role = 'manager' AND is_read = 0`,
      [userId]
    );
    res.json({ count: row?.count || 0 });
  } else {
    const row = dbGet<{ count: number }>(
      `SELECT COUNT(*) as count FROM manager_comments WHERE team_id = ? AND sender_role = 'member' AND is_read = 0`,
      [teamId]
    );
    res.json({ count: row?.count || 0 });
  }
});

// ===== MANAGER-ONLY ROUTES =====

// GET /api/daily/team?date=YYYY-MM-DD — Get all team members' daily data for a date
router.get('/team', requireManager, (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const date = (req.query.date as string) || todayStr();
  const currentMonth = currentMonthStr();

  const members = dbAll(
    `SELECT u.id, u.name, u.email, u.role, u.avatar_color,
            COALESCE(d.sales_amount, 0) as sales_amount,
            COALESCE(d.collection_amount, 0) as collection_amount,
            COALESCE(d.activity_count, 0) as activity_count,
            COALESCE(d.new_pd_count, 0) as new_pd_count,
            COALESCE(d.target_sales, 0) as target_sales,
            COALESCE(d.target_collection, 0) as target_collection,
            COALESCE(d.target_activity, 0) as target_activity,
            COALESCE(d.target_new_pd, 0) as target_new_pd,
            d.notes,
            d.updated_at,
            d.entry_date,
            mt.target_sales as monthly_target_sales,
            mt.target_collection as monthly_target_collection,
            mt.target_activity as monthly_target_activity,
            mt.target_new_pd as monthly_target_new_pd
     FROM users u
     LEFT JOIN daily_entries d ON d.user_id = u.id AND d.entry_date = ?
     LEFT JOIN monthly_targets mt ON mt.user_id = u.id AND mt.target_month = ?
     WHERE u.team_id = ?
     ORDER BY (CASE WHEN u.role = 'manager' THEN 0 ELSE 1 END), u.name`,
    [date, currentMonth, teamId]
  );

  res.json(members);
});

// GET /api/daily/team/mtd — Get team month-to-date aggregates  
router.get('/team/mtd', requireManager, (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const now = new Date();
  const monthStart = now.toISOString().slice(0, 7) + '-01';
  const today = todayStr();
  const currentMonth = currentMonthStr();

  // Per-member MTD totals & monthly targets
  const memberTotals = dbAll(
    `SELECT u.id, u.name, u.role, u.avatar_color,
            COALESCE(SUM(d.sales_amount), 0) as total_sales,
            COALESCE(SUM(d.collection_amount), 0) as total_collection,
            COALESCE(SUM(d.activity_count), 0) as total_activity,
            COALESCE(SUM(d.new_pd_count), 0) as total_new_pd,
            COALESCE(SUM(d.target_sales), 0) as total_target_sales,
            COALESCE(SUM(d.target_collection), 0) as total_target_collection,
            COALESCE(SUM(d.target_activity), 0) as total_target_activity,
            COALESCE(SUM(d.target_new_pd), 0) as total_target_new_pd,
            COUNT(d.id) as days_entered,
            mt.target_sales as monthly_target_sales,
            mt.target_collection as monthly_target_collection,
            mt.target_activity as monthly_target_activity,
            mt.target_new_pd as monthly_target_new_pd
     FROM users u
     LEFT JOIN daily_entries d ON d.user_id = u.id AND d.entry_date >= ? AND d.entry_date <= ?
     LEFT JOIN monthly_targets mt ON mt.user_id = u.id AND mt.target_month = ?
     WHERE u.team_id = ?
     GROUP BY u.id
     ORDER BY COALESCE(SUM(d.sales_amount), 0) DESC`,
    [monthStart, today, currentMonth, teamId]
  );

  // Team aggregate totals
  const teamTotal = dbGet<{
    total_sales: number;
    total_collection: number;
    total_activity: number;
    total_new_pd: number;
    total_target_sales: number;
    total_target_collection: number;
    total_target_activity: number;
    total_target_new_pd: number;
  }>(
    `SELECT 
      COALESCE(SUM(d.sales_amount), 0) as total_sales,
      COALESCE(SUM(d.collection_amount), 0) as total_collection,
      COALESCE(SUM(d.activity_count), 0) as total_activity,
      COALESCE(SUM(d.new_pd_count), 0) as total_new_pd,
      COALESCE(SUM(d.target_sales), 0) as total_target_sales,
      COALESCE(SUM(d.target_collection), 0) as total_target_collection,
      COALESCE(SUM(d.target_activity), 0) as total_target_activity,
      COALESCE(SUM(d.target_new_pd), 0) as total_target_new_pd
    FROM daily_entries d
    JOIN users u ON u.id = d.user_id
    WHERE d.team_id = ? AND d.entry_date >= ? AND d.entry_date <= ?`,
    [teamId, monthStart, today]
  );

  // Team monthly targets aggregate
  const teamMonthlyTarget = dbGet<{
    target_sales: number;
    target_collection: number;
    target_activity: number;
    target_new_pd: number;
  }>(
    `SELECT 
      COALESCE(SUM(target_sales), 0) as target_sales,
      COALESCE(SUM(target_collection), 0) as target_collection,
      COALESCE(SUM(target_activity), 0) as target_activity,
      COALESCE(SUM(target_new_pd), 0) as target_new_pd
     FROM monthly_targets
     WHERE team_id = ? AND target_month = ?`,
    [teamId, currentMonth]
  );

  res.json({
    memberTotals,
    teamTotal,
    teamMonthlyTarget: teamMonthlyTarget || null,
    monthStart,
    today,
  });
});

// GET /api/daily/team/:memberId/history — Get a member's daily entries for the month
router.get('/team/:memberId/history', requireManager, (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const memberId = String(req.params.memberId);
  const now = new Date();
  const monthStart = now.toISOString().slice(0, 7) + '-01';
  const today = todayStr();
  const currentMonth = currentMonthStr();

  // Verify member belongs to team
  const member = dbGet(`SELECT id, name, role FROM users WHERE id = ? AND team_id = ?`, [memberId, teamId]);
  if (!member) { res.status(404).json({ error: 'Member not found' }); return; }

  const entries = dbAll(
    `SELECT entry_date, sales_amount, collection_amount, activity_count, new_pd_count,
            target_sales, target_collection, target_activity, target_new_pd,
            notes, updated_at
     FROM daily_entries
     WHERE user_id = ? AND entry_date >= ? AND entry_date <= ?
     ORDER BY entry_date DESC`,
    [memberId, monthStart, today]
  );

  const monthlyTarget = dbGet(
    `SELECT * FROM monthly_targets WHERE user_id = ? AND target_month = ?`,
    [memberId, currentMonth]
  );

  res.json({ member, entries, monthlyTarget: monthlyTarget || null });
});

// POST /api/daily/comment — Manager posts a comment for a teammate
router.post('/comment', requireManager, (req: Request, res: Response) => {
  const { userId: managerId, teamId } = req.user!;
  const { memberId, comment, entryDate } = req.body;

  if (!memberId || !comment?.trim()) {
    res.status(400).json({ error: 'memberId and comment are required' });
    return;
  }

  // Verify member belongs to team
  const member = dbGet(`SELECT id FROM users WHERE id = ? AND team_id = ?`, [memberId, teamId]);
  if (!member) { res.status(404).json({ error: 'Member not found' }); return; }

  const mgr = dbGet<{ name: string }>(`SELECT name FROM users WHERE id = ?`, [managerId]);

  const id = randomUUID();
  dbRun(
    `INSERT INTO manager_comments (id, manager_id, member_id, team_id, sender_id, sender_name, sender_role, comment, entry_date, is_read)
     VALUES (?, ?, ?, ?, ?, ?, 'manager', ?, ?, 0)`,
    [id, managerId, memberId, teamId, managerId, mgr?.name || 'Manager', comment.trim(), entryDate || todayStr()]
  );

  const saved = dbGet(
    `SELECT mc.id, mc.comment, mc.entry_date, mc.created_at, mc.is_read,
            COALESCE(mc.sender_name, 'Manager') as sender_name,
            COALESCE(mc.sender_role, 'manager') as sender_role,
            mc.sender_id
     FROM manager_comments mc WHERE mc.id = ?`,
    [id]
  );
  res.json(saved);
});

// GET /api/daily/comments/:memberId — Manager gets comments/replies for a specific member
router.get('/comments/:memberId', requireManager, (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const memberId = String(req.params.memberId);

  const comments = dbAll(
    `SELECT mc.id, mc.comment, mc.entry_date, mc.created_at, mc.is_read,
            COALESCE(mc.sender_name, u.name, 'Manager') as sender_name,
            COALESCE(mc.sender_role, 'manager') as sender_role,
            mc.sender_id
     FROM manager_comments mc
     LEFT JOIN users u ON u.id = mc.sender_id
     WHERE mc.member_id = ? AND mc.team_id = ?
     ORDER BY mc.created_at ASC
     LIMIT 100`,
    [memberId, teamId]
  );

  // Mark member replies as read when manager views
  dbRun(`UPDATE manager_comments SET is_read = 1 WHERE member_id = ? AND team_id = ? AND sender_role = 'member'`, [memberId, teamId]);

  res.json(comments);
});

// GET /api/daily/target-window — Get daily target window status for current user
router.get('/target-window', (req: Request, res: Response) => {
  const { userId } = req.user!;
  const date = todayStr();
  const isOpen = isDailyTargetWindowOpen();

  const existing = dbGet<{ target_submitted_at: string | null }>(
    `SELECT target_submitted_at FROM daily_entries WHERE user_id = ? AND entry_date = ?`,
    [userId, date]
  );

  const isSubmitted = !!(existing?.target_submitted_at);

  res.json({
    isOpen,
    isSubmitted,
    canSubmit: isOpen && !isSubmitted,
    message: isSubmitted
      ? 'Daily target has already been submitted for today.'
      : isOpen
        ? 'Target window is open. You can set your daily target before 10:30 AM IST.'
        : 'Target window is closed. Daily targets can only be set before 10:30 AM IST.',
    closesAt: '10:30 AM IST',
    date,
  });
});

// GET /api/notifications — Get unseen notifications for manager
router.get('/notifications', requireManager, (req: Request, res: Response) => {
  const { teamId } = req.user!;

  const notifications = dbAll(
    `SELECT id, from_user_id, from_user_name, type, summary, is_seen, created_at
     FROM notifications
     WHERE team_id = ? AND is_seen = 0
     ORDER BY created_at DESC
     LIMIT 50`,
    [teamId]
  );

  res.json(notifications);
});

// POST /api/notifications/mark-seen — Mark all notifications as seen for manager
router.post('/notifications/mark-seen', requireManager, (req: Request, res: Response) => {
  const { teamId } = req.user!;
  dbRun(`UPDATE notifications SET is_seen = 1 WHERE team_id = ?`, [teamId]);
  res.json({ success: true });
});

export { router as dailyRouter };

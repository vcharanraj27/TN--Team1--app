import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { dbAll, dbGet, dbRun, QueryParam } from '../database';
import { authenticate } from '../middleware/auth';

const router = Router();
router.use(authenticate);

// GET /api/trips?month=2024-10
router.get('/', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const { month } = req.query;

  let query = `SELECT * FROM trips WHERE user_id = ? AND team_id = ?`;
  const params: QueryParam[] = [userId, teamId];

  if (month && typeof month === 'string') {
    query += ` AND strftime('%Y-%m', started_at) = ?`;
    params.push(month);
  }

  query += ` ORDER BY started_at DESC LIMIT 200`;
  const trips = dbAll(query, params);
  res.json(trips);
});

// GET /api/trips/:id
router.get('/:id', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const tripId = String(req.params.id);
  const trip = dbGet(
    `SELECT * FROM trips WHERE id = ? AND user_id = ? AND team_id = ?`,
    [tripId, userId, teamId]
  );
  if (!trip) { res.status(404).json({ error: 'Trip not found' }); return; }
  res.json(trip);
});

// GET /api/trips/:id/locations
router.get('/:id/locations', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const tripId = String(req.params.id);
  const trip = dbGet(
    `SELECT id FROM trips WHERE id = ? AND user_id = ? AND team_id = ?`,
    [tripId, userId, teamId]
  );
  if (!trip) { res.status(404).json({ error: 'Trip not found' }); return; }

  const locations = dbAll(
    `SELECT id, lat, lng, accuracy, speed, heading, altitude, timestamp
     FROM locations WHERE trip_id = ? AND user_id = ? AND team_id = ? ORDER BY timestamp ASC`,
    [tripId, userId, teamId]
  );
  res.json(locations);
});

// POST /api/trips — start a new trip
router.post('/', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;

  const active = dbGet(
    `SELECT id FROM trips WHERE user_id = ? AND team_id = ? AND status IN ('active','paused')`,
    [userId, teamId]
  );
  if (active) {
    res.status(409).json({ error: 'You already have an active trip. Stop it before starting a new one.' });
    return;
  }

  const id = uuidv4();
  const { startLat, startLng, startAddress } = req.body;

  dbRun(
    `INSERT INTO trips (id, user_id, team_id, status, start_lat, start_lng, start_address, started_at)
     VALUES (?, ?, ?, 'active', ?, ?, ?, datetime('now'))`,
    [id, userId, teamId, startLat ?? null, startLng ?? null, startAddress ?? null]
  );

  const trip = dbGet(`SELECT * FROM trips WHERE id = ?`, [id]);
  res.status(201).json(trip);
});

// PATCH /api/trips/:id — pause / resume / stop
router.patch('/:id', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const tripId = String(req.params.id);
  const { action, endLat, endLng, endAddress, distanceM, durationS } = req.body;

  const trip = dbGet<{ id: string; status: string }>(
    `SELECT * FROM trips WHERE id = ? AND user_id = ? AND team_id = ?`,
    [tripId, userId, teamId]
  );
  if (!trip) { res.status(404).json({ error: 'Trip not found' }); return; }

  if (action === 'pause') {
    if (trip.status !== 'active') { res.status(400).json({ error: 'Trip is not active' }); return; }
    dbRun(`UPDATE trips SET status='paused', paused_at=datetime('now') WHERE id = ?`, [trip.id]);
  } else if (action === 'resume') {
    if (trip.status !== 'paused') { res.status(400).json({ error: 'Trip is not paused' }); return; }
    dbRun(`UPDATE trips SET status='active', paused_at=NULL WHERE id = ?`, [trip.id]);
  } else if (action === 'stop') {
    if (trip.status === 'completed') { res.status(400).json({ error: 'Trip already completed' }); return; }
    dbRun(
      `UPDATE trips SET status='completed', ended_at=datetime('now'),
       end_lat=?, end_lng=?, end_address=?,
       distance_m=COALESCE(?, distance_m), duration_s=COALESCE(?, duration_s)
       WHERE id = ?`,
      [endLat ?? null, endLng ?? null, endAddress ?? null, distanceM ?? null, durationS ?? null, trip.id]
    );
  } else {
    res.status(400).json({ error: 'Invalid action. Use pause, resume, or stop.' }); return;
  }

  const updated = dbGet(`SELECT * FROM trips WHERE id = ?`, [trip.id]);
  res.json(updated);
});

// DELETE /api/trips/:id
router.delete('/:id', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const tripId = String(req.params.id);
  const trip = dbGet(
    `SELECT id FROM trips WHERE id = ? AND user_id = ? AND team_id = ?`,
    [tripId, userId, teamId]
  );
  if (!trip) { res.status(404).json({ error: 'Trip not found' }); return; }
  dbRun(`DELETE FROM locations WHERE trip_id = ?`, [tripId]);
  dbRun(`DELETE FROM trips WHERE id = ?`, [tripId]);
  res.json({ success: true });
});

export { router as tripsRouter };

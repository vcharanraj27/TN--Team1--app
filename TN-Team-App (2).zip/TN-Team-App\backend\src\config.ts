import dotenv from 'dotenv';
dotenv.config();

const nodeEnv = process.env.NODE_ENV || 'development';
const jwtSecret = process.env.JWT_SECRET || (nodeEnv === 'production' ? '' : 'dev-secret-change-in-production');

if (!jwtSecret) {
  throw new Error('JWT_SECRET must be configured in production');
}

export const config = {
  port: parseInt(process.env.PORT || '4000', 10),
  jwtSecret,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  dbPath: process.env.DB_PATH || './data/tracker.db',
  nodeEnv,
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
};


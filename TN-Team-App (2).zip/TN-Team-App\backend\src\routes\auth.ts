import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { dbAll, dbGet, dbRun } from '../database';
import { config } from '../config';
import { authenticate } from '../middleware/auth';
import { randomUUID } from 'crypto';

const router = Router();

const AVATAR_COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#14b8a6',
  '#3b82f6', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16', '#f59e0b',
];

// GET /api/auth/teams — public list of teams to join
router.get('/teams', (_req: Request, res: Response) => {
  const teams = dbAll<{ id: string; name: string; member_count: number }>(
    `SELECT t.id, t.name, COUNT(u.id) as member_count
     FROM teams t
     LEFT JOIN users u ON u.team_id = t.id
     GROUP BY t.id
     ORDER BY t.name ASC`
  );
  res.json(teams);
});

// POST /api/auth/register — register a new manager or teammate
router.post('/register', async (req: Request, res: Response) => {
  const { name, email, password, role, teamId, teamName, teamPassword } = req.body;

  if (!name || !email || !password || !role) {
    res.status(400).json({ error: 'Name, email, password, and role are required' });
    return;
  }

  const cleanRole = role === 'manager' ? 'manager' : 'member';
  const cleanEmail = email.toLowerCase().trim();

  // Check if email already exists
  const existing = dbGet('SELECT id FROM users WHERE email = ?', [cleanEmail]);
  if (existing) {
    res.status(409).json({ error: 'An account with this email already exists' });
    return;
  }

  let finalTeamId = teamId;
  let finalTeamName = teamName;

  if (cleanRole === 'manager') {
    if (!teamName || !teamName.trim()) {
      res.status(400).json({ error: 'Team name is required for managers' });
      return;
    }
    if (!teamPassword || !teamPassword.trim()) {
      res.status(400).json({ error: 'Please set a Team Password so teammates can join your team' });
      return;
    }

    // Check if team name already exists
    const existingTeam = dbGet<{ id: string }>('SELECT id FROM teams WHERE lower(name) = ?', [teamName.trim().toLowerCase()]);
    if (existingTeam) {
      res.status(409).json({ error: 'A team with this name already exists. Please choose a different team name.' });
      return;
    }

    // Manager creates a brand new team with their chosen join password
    finalTeamId = uuidv4();
    finalTeamName = teamName.trim();
    dbRun(
      `INSERT INTO teams (id, name, join_password) VALUES (?, ?, ?)`,
      [finalTeamId, finalTeamName, teamPassword.trim()]
    );
  } else {
    // Teammate registration: Must select team and provide correct team password
    if (!teamId) {
      res.status(400).json({ error: 'Please select a team to join' });
      return;
    }
    if (!teamPassword || !teamPassword.trim()) {
      res.status(400).json({ error: 'Team password is required to join this team' });
      return;
    }

    const team = dbGet<{ id: string; name: string; join_password: string }>(
      'SELECT id, name, join_password FROM teams WHERE id = ?',
      [teamId]
    );

    if (!team) {
      res.status(404).json({ error: 'Selected team not found' });
      return;
    }

    // Verify team password
    if (team.join_password.trim() !== teamPassword.trim()) {
      res.status(403).json({
        error: 'Incorrect Team Password. Please ask your team manager for the correct team join password.',
      });
      return;
    }

    finalTeamId = team.id;
    finalTeamName = team.name;
  }

  const userId = uuidv4();
  const passwordHash = await bcrypt.hash(password, 10);
  const avatarColor = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

  dbRun(
    `INSERT INTO users (id, team_id, name, email, password_hash, role, avatar_color)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [userId, finalTeamId, name.trim(), cleanEmail, passwordHash, cleanRole, avatarColor]
  );

  const token = jwt.sign(
    { userId, teamId: finalTeamId, role: cleanRole },
    config.jwtSecret,
    { expiresIn: config.jwtExpiresIn as jwt.SignOptions['expiresIn'] }
  );

  res.status(201).json({
    token,
    user: {
      id: userId,
      name: name.trim(),
      email: cleanEmail,
      role: cleanRole,
      teamId: finalTeamId,
      teamName: finalTeamName,
      avatarColor,
      teamJoinPassword: cleanRole === 'manager' ? teamPassword.trim() : undefined,
    },
  });
});

// POST /api/auth/login
router.post('/login', async (req: Request, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400).json({ error: 'Email and password are required' });
    return;
  }

  const user = dbGet<{
    id: string; name: string; email: string; password_hash: string;
    role: string; team_id: string; avatar_color: string; team_name: string;
    join_password: string;
  }>(
    `SELECT u.id, u.name, u.email, u.password_hash, u.role, u.team_id, u.avatar_color,
            t.name as team_name, t.join_password
     FROM users u JOIN teams t ON t.id = u.team_id
     WHERE u.email = ?`,
    [email.toLowerCase().trim()]
  );

  if (!user) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  const token = jwt.sign(
    { userId: user.id, teamId: user.team_id, role: user.role },
    config.jwtSecret,
    { expiresIn: config.jwtExpiresIn as jwt.SignOptions['expiresIn'] }
  );

  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      teamId: user.team_id,
      teamName: user.team_name,
      avatarColor: user.avatar_color,
      teamJoinPassword: user.role === 'manager' ? user.join_password : undefined,
    },
  });
});

// GET /api/auth/me
router.get('/me', authenticate, (req: Request, res: Response) => {
  const user = dbGet<{
    id: string; name: string; email: string; role: string;
    team_id: string; avatar_color: string; team_name: string;
    join_password: string;
  }>(
    `SELECT u.id, u.name, u.email, u.role, u.team_id, u.avatar_color,
            t.name as team_name, t.join_password
     FROM users u JOIN teams t ON t.id = u.team_id
     WHERE u.id = ?`,
    [req.user!.userId]
  );

  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    teamId: user.team_id,
    teamName: user.team_name,
    avatarColor: user.avatar_color,
    teamJoinPassword: user.role === 'manager' ? user.join_password : undefined,
  });
});

// In-memory OTP store (simple approach for this app)
const otpStore = new Map<string, { code: string; expiresAt: number; userId: string }>();

// POST /api/auth/forgot-password — send a reset code
router.post('/forgot-password', (req: Request, res: Response) => {
  if (config.nodeEnv === 'production') {
    res.status(503).json({ error: 'Password reset is not configured. Contact your team manager.' });
    return;
  }

  const { email } = req.body;
  if (!email) {
    res.status(400).json({ error: 'Email is required' });
    return;
  }

  const cleanEmail = email.toLowerCase().trim();
  const user = dbGet<{ id: string; name: string; email: string }>(
    `SELECT id, name, email FROM users WHERE email = ?`,
    [cleanEmail]
  );

  if (!user) {
    res.status(404).json({ error: 'No account found with this email address' });
    return;
  }

  // Generate 6-digit OTP
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = Date.now() + 5 * 60 * 1000; // 5 minutes

  // Store OTP
  otpStore.set(cleanEmail, { code, expiresAt, userId: user.id });

  // Clean up expired codes periodically
  for (const [key, val] of otpStore.entries()) {
    if (val.expiresAt < Date.now()) otpStore.delete(key);
  }

  console.log(`🔑 Password reset code for ${cleanEmail}: ${code}`);

  // Return the code in the response for this local app
  // In production, you would send this via email using Nodemailer/SendGrid
  res.json({
    success: true,
    message: `Verification code sent to ${cleanEmail}`,
    // Include code for local/demo app (remove in production)
    code,
    expiresInMinutes: 5,
  });
});

// POST /api/auth/verify-code — verify OTP and sign in
router.post('/verify-code', (req: Request, res: Response) => {
  const { email, code } = req.body;
  if (!email || !code) {
    res.status(400).json({ error: 'Email and code are required' });
    return;
  }

  const cleanEmail = email.toLowerCase().trim();
  const stored = otpStore.get(cleanEmail);

  if (!stored) {
    res.status(400).json({ error: 'No verification code found. Please request a new one.' });
    return;
  }

  if (stored.expiresAt < Date.now()) {
    otpStore.delete(cleanEmail);
    res.status(400).json({ error: 'Code has expired. Please request a new one.' });
    return;
  }

  if (stored.code !== code.trim()) {
    res.status(400).json({ error: 'Incorrect verification code. Please try again.' });
    return;
  }

  // Code is valid — delete it and sign the user in
  otpStore.delete(cleanEmail);

  const user = dbGet<{
    id: string; name: string; email: string; role: string;
    team_id: string; avatar_color: string; team_name: string;
    join_password: string;
  }>(
    `SELECT u.id, u.name, u.email, u.role, u.team_id, u.avatar_color,
            t.name as team_name, t.join_password
     FROM users u JOIN teams t ON t.id = u.team_id
     WHERE u.id = ?`,
    [stored.userId]
  );

  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  const token = jwt.sign(
    { userId: user.id, teamId: user.team_id, role: user.role },
    config.jwtSecret,
    { expiresIn: config.jwtExpiresIn as jwt.SignOptions['expiresIn'] }
  );

  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      teamId: user.team_id,
      teamName: user.team_name,
      avatarColor: user.avatar_color,
      teamJoinPassword: user.role === 'manager' ? user.join_password : undefined,
    },
  });
});

export { router as authRouter };


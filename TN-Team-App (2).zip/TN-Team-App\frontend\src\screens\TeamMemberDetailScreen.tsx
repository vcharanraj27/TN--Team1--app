import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { TeamMember, Trip, Location } from '../types';
import { Avatar } from '../components/Avatar';
import { TripMap } from '../components/TripMap';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/States';
import {
  formatDate,
  formatDistance,
  formatDuration,
  formatTime,
  timeAgo,
  toMonthStr,
  formatMonth,
} from '../utils';
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Clock,
  Activity,
  Navigation2,
  X,
  UserMinus,
  AlertTriangle,
  Loader2,
  Trash2,
} from 'lucide-react';

export function TeamMemberDetailScreen() {
  const { userId } = useParams<{ userId: string }>();
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [member, setMember] = useState<TeamMember | null>(null);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [tripLocations, setTripLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentDate, setCurrentDate] = useState(new Date());

  // Removal state
  const [showRemoveModal, setShowRemoveModal] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [removeError, setRemoveError] = useState('');

  const month = toMonthStr(currentDate);

  useEffect(() => {
    if (!token || !userId) return;
    Promise.all([
      api.manager.member(token, userId),
      api.manager.memberTrips(token, userId, month),
    ])
      .then(([m, t]) => { setMember(m); setTrips(t); })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [token, userId, month]);

  const loadTripLocations = async (trip: Trip) => {
    if (!token || !userId) return;
    setSelectedTrip(trip);
    try {
      const locs = await api.manager.memberTripLocations(token, userId, trip.id);
      setTripLocations(locs);
    } catch (e) {
      console.error('Failed to load locations:', e);
    }
  };

  const prevMonth = () => {
    const d = new Date(currentDate);
    d.setMonth(d.getMonth() - 1);
    setCurrentDate(d);
  };
  const nextMonth = () => {
    const d = new Date(currentDate);
    d.setMonth(d.getMonth() + 1);
    if (d > new Date()) return;
    setCurrentDate(d);
  };

  const handleConfirmRemove = async () => {
    if (!token || !userId) return;
    setRemoving(true);
    setRemoveError('');
    try {
      await api.manager.deleteMember(token, userId);
      setShowRemoveModal(false);
      navigate('/team');
    } catch (e) {
      setRemoveError(e instanceof Error ? e.message : 'Failed to remove teammate');
    } finally {
      setRemoving(false);
    }
  };

  if (loading) return <LoadingSpinner fullScreen message="Loading member records..." />;

  const monthTotal = {
    distance: trips.reduce((a, t) => a + t.distance_m, 0),
    duration: trips.reduce((a, t) => a + t.duration_s, 0),
    count: trips.length,
  };

  return (
    <div className="h-full flex flex-col bg-slate-50 relative">
      {/* TOP APP BAR */}
      <div className="bg-white/95 backdrop-blur-md px-4 pt-12 pb-4 border-b border-slate-200/80 sticky top-0 z-20">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(-1)}
              className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 active:scale-95 transition-all"
            >
              <ArrowLeft className="w-5 h-5 text-slate-700" />
            </button>
            <div>
              <h1 className="text-base font-black text-slate-900 tracking-tight">Teammate Profile</h1>
              <p className="text-xs text-slate-500 font-medium">Activity &amp; logged trips</p>
            </div>
          </div>

          {/* Remove teammate button for managers */}
          {user?.role === 'manager' && member?.role !== 'manager' && (
            <button
              onClick={() => setShowRemoveModal(true)}
              className="px-3 py-1.5 bg-red-50 hover:bg-red-100 active:bg-red-200 text-red-600 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors border border-red-200/80 shadow-sm"
              title="Remove Teammate"
            >
              <UserMinus className="w-3.5 h-3.5" />
              Remove Teammate
            </button>
          )}
        </div>

        {member && (
          <div className="bg-slate-50 border border-slate-100 rounded-3xl p-3.5 flex items-center gap-3.5">
            <div className="relative shrink-0">
              <Avatar name={member.name} color={member.avatar_color} size="lg" />
              {member.active_status === 'active' && (
                <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white tracking-pulse" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-black text-slate-900 truncate">{member.name}</p>
              <p className="text-xs text-slate-500 truncate">{member.email}</p>
              <div className="flex items-center gap-2 mt-1">
                {member.active_status === 'active' ? (
                  <span className="flex items-center gap-1 text-[11px] font-bold text-green-700 bg-green-100/80 px-2 py-0.5 rounded-lg">
                    <Activity className="w-3 h-3" /> Tracking Live
                  </span>
                ) : member.last_seen ? (
                  <span className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                    <Clock className="w-3 h-3" /> Seen {timeAgo(member.last_seen)}
                  </span>
                ) : (
                  <span className="text-[11px] text-slate-400">No telemetry recorded</span>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {error && <ErrorBanner message={error} />}

      <div className="flex-1 overflow-y-auto pb-24">
        {/* SELECTED TRIP ROUTE MAP REPLAY */}
        {selectedTrip && (
          <div className="bg-white border-b border-slate-200 slide-up shadow-sm">
            <div className="relative">
              <TripMap locations={tripLocations} className="h-56" />
              <button
                onClick={() => setSelectedTrip(null)}
                className="absolute top-3 right-3 w-8 h-8 glass-card rounded-full flex items-center justify-center text-slate-700 shadow-md active:scale-90 z-10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="px-4 py-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-900">{formatDate(selectedTrip.started_at)} • {formatTime(selectedTrip.started_at)}</p>
                <div className="flex gap-2 text-xs text-slate-500 mt-0.5 font-mono">
                  <span className="font-bold text-blue-600">{formatDistance(selectedTrip.distance_m)}</span>
                  <span>•</span>
                  <span>{formatDuration(selectedTrip.duration_s)}</span>
                </div>
              </div>
              <button
                onClick={() => setSelectedTrip(null)}
                className="text-xs text-slate-500 font-bold px-2.5 py-1 bg-slate-100 rounded-lg hover:bg-slate-200"
              >
                Close Map
              </button>
            </div>
          </div>
        )}

        {/* MONTH SELECTOR */}
        <div className="flex items-center justify-between mx-4 mt-3 bg-white border border-slate-100 rounded-2xl px-2 py-1 shadow-sm">
          <button onClick={prevMonth} className="p-2 rounded-xl hover:bg-slate-100 transition-colors">
            <ChevronLeft className="w-4 h-4 text-slate-600" />
          </button>
          <span className="text-xs font-black text-slate-900 uppercase tracking-wider">{formatMonth(month)}</span>
          <button
            onClick={nextMonth}
            disabled={toMonthStr(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1)) > toMonthStr(new Date())}
            className="p-2 rounded-xl hover:bg-slate-100 disabled:opacity-20 transition-colors"
          >
            <ChevronRight className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        {/* MONTHLY SUMMARY METRICS */}
        <div className="px-4 mt-3 grid grid-cols-3 gap-2.5">
          <div className="bg-white border border-slate-100 rounded-2xl p-3 text-center shadow-sm">
            <p className="text-lg font-black text-slate-900 font-mono">{monthTotal.count}</p>
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Trips</p>
          </div>
          <div className="bg-white border border-slate-100 rounded-2xl p-3 text-center shadow-sm">
            <p className="text-lg font-black text-blue-600 font-mono">{formatDistance(monthTotal.distance)}</p>
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Distance</p>
          </div>
          <div className="bg-white border border-slate-100 rounded-2xl p-3 text-center shadow-sm">
            <p className="text-lg font-black text-slate-900 font-mono">{formatDuration(monthTotal.duration)}</p>
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Drive Time</p>
          </div>
        </div>

        {/* TRIP LIST */}
        <div className="px-4 mt-4 space-y-2.5">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Monthly Routes
            </h3>
            <span className="text-xs text-slate-400 font-medium">{trips.length} trips</span>
          </div>

          {trips.length === 0 ? (
            <EmptyState
              icon={<Navigation2 className="w-10 h-10" />}
              title="No trips recorded"
              description="This teammate has no recorded trips for this month."
            />
          ) : (
            trips.map(trip => (
              <button
                key={trip.id}
                onClick={() => loadTripLocations(trip)}
                className={`w-full bg-white border rounded-3xl p-3.5 text-left transition-all active:scale-[0.99] flex flex-col gap-1.5 ${
                  selectedTrip?.id === trip.id
                    ? 'border-blue-500 ring-2 ring-blue-500/20 shadow-md'
                    : 'border-slate-100 shadow-sm hover:shadow-md'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-900">{formatDate(trip.started_at)}</span>
                    <span className="text-xs text-slate-400 ml-1.5 font-mono">{formatTime(trip.started_at)}</span>
                  </div>
                  <span className="text-xs font-bold text-blue-600 font-mono flex items-center gap-1">
                    <Navigation2 className="w-3 h-3" />
                    {formatDistance(trip.distance_m)}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {formatDuration(trip.duration_s)}
                  </span>
                  {trip.end_address && <span className="truncate">→ {trip.end_address}</span>}
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* REMOVE TEAMMATE CONFIRMATION MODAL */}
      {showRemoveModal && member && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 slide-up">
            <div className="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-inner">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-slate-900 text-center mb-1">
              Remove Teammate?
            </h3>
            <p className="text-xs text-slate-500 text-center leading-relaxed mb-4">
              Are you sure you want to remove <strong className="text-slate-800">{member.name}</strong> ({member.email}) from the team?
            </p>

            <div className="bg-red-50 border border-red-200/80 rounded-2xl p-3 mb-4 text-[11px] text-red-700 leading-relaxed">
              ⚠️ This will remove their profile and delete their location telemetry, trip history, daily reports, and targets from this team.
            </div>

            {removeError && (
              <div className="mb-3 p-2.5 bg-red-100 text-red-700 text-xs rounded-xl font-medium">
                {removeError}
              </div>
            )}

            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => { setShowRemoveModal(false); setRemoveError(''); }}
                disabled={removing}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRemove}
                disabled={removing}
                className="flex-1 py-3 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-red-600/30 transition-all disabled:opacity-50"
              >
                {removing ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Removing...</>
                ) : (
                  <><Trash2 className="w-4 h-4" /> Confirm &amp; Remove</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

@echo off
title TN Team - Database Backup Utility
color 0B
echo ===================================================
echo           TN TEAM - DATABASE BACKUP
echo ===================================================
echo.

cd /d "%~dp0"
if not exist "backend\data\tracker.db" (
    echo [ERROR] No active database found at backend\data\tracker.db
    pause
    exit /b 1
)

if not exist "backend\data\backups" (
    mkdir "backend\data\backups"
)

for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c-%%a-%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a%%b)
set timestamp=%mydate%_%mytime%

copy "backend\data\tracker.db" "backend\data\backups\tracker-manual-%timestamp%.db" >nul

echo [SUCCESS] Backup created at: backend\data\backups\tracker-manual-%timestamp%.db
echo.
pause

import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { TeamMember, Location, Trip } from '../types';
import { TeamMap } from '../components/TeamMap';
import { Avatar } from '../components/Avatar';
import { LoadingSpinner, ErrorBanner } from '../components/States';
import { timeAgo, formatDistance, formatDuration } from '../utils';
import {
  ChevronRight,
  Activity,
  Clock,
  Navigation2,
  Users,
  Compass,
  Play,
  Pause,
  Square,
  Sparkles,
  Navigation,
  Crosshair,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface LiveLocation {
  member: TeamMember;
  location: Location | null;
}

interface TrackingState {
  isTracking: boolean;
  isPaused: boolean;
  tripId: string | null;
  startTime: number | null;
  distance: number;
  elapsed: number;
  routeLocations: Location[];
  prevLat?: number;
  prevLng?: number;
}

export function ManagerMapScreen() {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'team' | 'my-gps'>('team');
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [liveLocations, setLiveLocations] = useState<LiveLocation[]>([]);
  const [selectedId, setSelectedId] = useState<string | undefined>();
  const [filter, setFilter] = useState<'all' | 'active' | 'idle'>('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Manager's Personal GPS Tracking state
  const [currentLat, setCurrentLat] = useState<number | undefined>();
  const [currentLng, setCurrentLng] = useState<number | undefined>();
  const [speedKmh, setSpeedKmh] = useState<number>(0);
  const [accuracyM, setAccuracyM] = useState<number | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [myTrips, setMyTrips] = useState<Trip[]>([]);

  const [tracking, setTracking] = useState<TrackingState>({
    isTracking: false,
    isPaused: false,
    tripId: null,
    startTime: null,
    distance: 0,
    elapsed: 0,
    routeLocations: [],
  });

  const watchId = useRef<number | null>(null);
  const simTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const trackingRef = useRef(tracking);
  trackingRef.current = tracking;

  // Load Team Radar data
  const loadTeam = async () => {
    if (!token) return;
    try {
      const team = await api.manager.team(token);
      setMembers(team);

      const locations = await Promise.all(
        team.map(async (m) => {
          try {
            const loc = await api.manager.memberLocation(token, m.id);
            return { member: m, location: loc };
          } catch {
            return { member: m, location: null };
          }
        })
      );
      setLiveLocations(locations);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load team data');
    } finally {
      setLoading(false);
    }
  };

  // Load Manager's personal trips
  const loadMyTrips = async () => {
    if (!token) return;
    try {
      const trips = await api.trips.list(token);
      setMyTrips(trips.slice(0, 5));
    } catch {}
  };

  useEffect(() => {
    loadTeam();
    loadMyTrips();
    const interval = setInterval(loadTeam, 15000);
    return () => clearInterval(interval);
  }, [token]);

  // GPS Watch position
  const startLocationWatch = useCallback(() => {
    if (!navigator.geolocation) return;

    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setCurrentLat(lat);
        setCurrentLng(lng);
        setSpeedKmh(pos.coords.speed ? Math.round(pos.coords.speed * 3.6) : 0);
        setAccuracyM(pos.coords.accuracy ? Math.round(pos.coords.accuracy) : null);

        const t = trackingRef.current;
        if (t.isTracking && !t.isPaused && t.tripId && token) {
          let dist = t.distance;
          if (t.prevLat !== undefined && t.prevLng !== undefined) {
            const R = 6371000;
            const φ1 = (t.prevLat * Math.PI) / 180;
            const φ2 = (lat * Math.PI) / 180;
            const Δφ = ((lat - t.prevLat) * Math.PI) / 180;
            const Δλ = ((lng - t.prevLng) * Math.PI) / 180;
            const a = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
            dist += R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
          }

          const newLoc: Location = {
            id: Date.now().toString(),
            lat,
            lng,
            accuracy: pos.coords.accuracy,
            speed: pos.coords.speed,
            heading: pos.coords.heading,
            altitude: pos.coords.altitude,
            timestamp: new Date().toISOString(),
          };

          setTracking(prev => ({
            ...prev,
            distance: dist,
            prevLat: lat,
            prevLng: lng,
            routeLocations: [...prev.routeLocations, newLoc],
          }));

          api.locations.post(token, {
            lat,
            lng,
            accuracy: pos.coords.accuracy,
            speed: pos.coords.speed,
            tripId: t.tripId,
            isTracking: true,
          }).catch(console.error);
        }
      },
      () => {
        if (currentLat === undefined) {
          setCurrentLat(13.0827);
          setCurrentLng(80.2707);
        }
      },
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 10000 }
    );
  }, [token, currentLat]);

  // Demo simulator for testing GPS movement
  const toggleSimulation = () => {
    if (isSimulating) {
      if (simTimer.current) clearInterval(simTimer.current);
      setIsSimulating(false);
      return;
    }

    setIsSimulating(true);
    let lat = currentLat || 13.0827;
    let lng = currentLng || 80.2707;
    setCurrentLat(lat);
    setCurrentLng(lng);

    simTimer.current = setInterval(() => {
      lat += (Math.random() - 0.48) * 0.0008;
      lng += (Math.random() - 0.48) * 0.0008;
      setCurrentLat(lat);
      setCurrentLng(lng);
      setSpeedKmh(Math.floor(20 + Math.random() * 25));
      setAccuracyM(5);

      const t = trackingRef.current;
      if (t.isTracking && !t.isPaused && t.tripId && token) {
        let dist = t.distance;
        if (t.prevLat !== undefined && t.prevLng !== undefined) {
          const R = 6371000;
          const φ1 = (t.prevLat * Math.PI) / 180;
          const φ2 = (lat * Math.PI) / 180;
          const Δφ = ((lat - t.prevLat) * Math.PI) / 180;
          const Δλ = ((lng - t.prevLng) * Math.PI) / 180;
          const a = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
          dist += R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        }

        const newLoc: Location = {
          id: Date.now().toString(),
          lat,
          lng,
          accuracy: 5,
          speed: 8.5,
          heading: 90,
          altitude: 20,
          timestamp: new Date().toISOString(),
        };

        setTracking(prev => ({
          ...prev,
          distance: dist,
          prevLat: lat,
          prevLng: lng,
          routeLocations: [...prev.routeLocations, newLoc],
        }));

        api.locations.post(token, {
          lat,
          lng,
          accuracy: 5,
          speed: 8.5,
          tripId: t.tripId,
          isTracking: true,
        }).catch(console.error);
      }
    }, 2000);
  };

  useEffect(() => {
    return () => {
      if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current);
      if (simTimer.current) clearInterval(simTimer.current);
    };
  }, []);

  // Timer tick for active trip
  useEffect(() => {
    if (tracking.isTracking && !tracking.isPaused && tracking.startTime) {
      tickRef.current = setInterval(() => {
        setTracking(prev => ({
          ...prev,
          elapsed: Math.floor((Date.now() - (prev.startTime ?? Date.now())) / 1000),
        }));
      }, 1000);
    } else {
      if (tickRef.current) clearInterval(tickRef.current);
    }
    return () => { if (tickRef.current) clearInterval(tickRef.current); };
  }, [tracking.isTracking, tracking.isPaused]);

  const handleStartTracking = async () => {
    if (!token) return;
    setError('');
    try {
      const trip = await api.trips.start(token, {
        startLat: currentLat,
        startLng: currentLng,
        startAddress: 'Trip origin point',
      });
      setTracking({
        isTracking: true,
        isPaused: false,
        tripId: trip.id,
        startTime: Date.now(),
        distance: 0,
        elapsed: 0,
        routeLocations: currentLat && currentLng ? [{
          id: Date.now().toString(),
          lat: currentLat,
          lng: currentLng,
          accuracy: accuracyM,
          speed: 0,
          heading: 0,
          altitude: null,
          timestamp: new Date().toISOString(),
        }] : [],
        prevLat: currentLat,
        prevLng: currentLng,
      });
      if (!watchId.current && !isSimulating) startLocationWatch();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to start trip');
    }
  };

  const handlePauseResume = async () => {
    if (!token || !tracking.tripId) return;
    try {
      const action = tracking.isPaused ? 'resume' : 'pause';
      await api.trips.update(token, tracking.tripId, { action });
      setTracking(prev => ({
        ...prev,
        isPaused: !prev.isPaused,
        startTime: prev.isPaused ? Date.now() - prev.elapsed * 1000 : prev.startTime,
      }));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to update trip');
    }
  };

  const handleStop = async () => {
    if (!token || !tracking.tripId) return;
    try {
      await api.trips.update(token, tracking.tripId, {
        action: 'stop',
        endLat: currentLat,
        endLng: currentLng,
        endAddress: 'Trip destination',
        distanceM: Math.round(tracking.distance),
        durationS: tracking.elapsed,
      });
      setTracking({
        isTracking: false,
        isPaused: false,
        tripId: null,
        startTime: null,
        distance: 0,
        elapsed: 0,
        routeLocations: [],
      });
      loadMyTrips();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to stop trip');
    }
  };

  const activeCount = members.filter(m => m.active_status === 'active').length;
  const filteredMembers = members.filter(m => {
    if (filter === 'active') return m.active_status === 'active' || m.active_status === 'paused';
    if (filter === 'idle') return !m.active_status;
    return true;
  });

  const selectedMember = members.find(m => m.id === selectedId);

  if (loading) return <LoadingSpinner fullScreen message="Connecting to team radar..." />;

  return (
    <div className="h-full flex flex-col relative bg-slate-900">
      {/* TOP HEADER */}
      <div className="absolute top-0 left-0 right-0 p-3 pt-safe z-20 pointer-events-none">
        <div className="flex items-center justify-between pointer-events-auto">
          <div className="glass-card px-3.5 py-2 rounded-2xl shadow-lg flex items-center gap-2.5">
            <div className="w-7 h-7 bg-purple-600 rounded-full flex items-center justify-center font-bold text-white text-xs shadow-inner">
              👑
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 leading-tight">Manager Radar</p>
              <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">{user?.teamName}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {activeTab === 'my-gps' && (
              <button
                onClick={toggleSimulation}
                className={`glass-card px-2.5 py-1.5 rounded-2xl text-[11px] font-bold shadow-md flex items-center gap-1 transition-colors ${
                  isSimulating ? 'bg-amber-500 text-white border-amber-400' : 'text-slate-700 hover:bg-white'
                }`}
                title="Toggle GPS Simulation"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isSimulating ? 'Simulating' : 'Simulate'}
              </button>
            )}

            <div className="glass-card px-3 py-1.5 rounded-2xl shadow-md flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500 tracking-pulse" />
              <span className="text-xs font-bold text-slate-800">
                {activeCount} Active
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* MAP CANVAS */}
      <div className="flex-1 relative overflow-hidden">
        <TeamMap
          members={liveLocations}
          selectedMemberId={selectedId}
          onMemberClick={(m) => setSelectedId(m.id === selectedId ? undefined : m.id)}
          className="absolute inset-0"
          myLat={currentLat}
          myLng={currentLng}
        />
        {error && (
          <div className="absolute top-16 left-4 right-4 z-20">
            <ErrorBanner message={error} onRetry={loadTeam} />
          </div>
        )}
      </div>

      {/* BOTTOM DRAWER (DISPLAYED BELOW MAP) */}
      <div className="glass-card rounded-t-[32px] px-4 pt-3 pb-20 shadow-2xl border-t border-white/60 z-30 flex flex-col max-h-[52%]">
        <div className="w-10 h-1 bg-slate-200 rounded-full mx-auto mb-2.5 shrink-0" />

        {/* MODE SWITCHER: Team Radar vs My Live GPS Trips */}
        <div className="flex bg-slate-100 p-1 rounded-2xl mb-3 shrink-0 border border-slate-200/80 shadow-inner">
          <button
            onClick={() => setActiveTab('team')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'team'
                ? 'bg-white text-purple-700 shadow-md scale-[1.01]'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4 text-purple-600" />
            Team Radar ({members.length})
          </button>
          <button
            onClick={() => setActiveTab('my-gps')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'my-gps'
                ? 'bg-white text-blue-700 shadow-md scale-[1.01]'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Navigation2 className="w-4 h-4 text-blue-500" />
            My Live GPS Trips {tracking.isTracking && <span className="w-2 h-2 rounded-full bg-green-500 tracking-pulse" />}
          </button>
        </div>

        {/* TAB 1: TEAM RADAR CONTENT */}
        {activeTab === 'team' && (
          <div className="flex flex-col flex-1 min-h-0">
            {/* Filter Pills */}
            <div className="flex items-center justify-between gap-1.5 mb-2.5 shrink-0">
              <div className="flex gap-1.5">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    filter === 'all'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  All ({members.length})
                </button>
                <button
                  onClick={() => setFilter('active')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                    filter === 'active'
                      ? 'bg-green-600 text-white shadow-sm'
                      : 'bg-green-50 text-green-700 hover:bg-green-100'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                  Active ({activeCount})
                </button>
                <button
                  onClick={() => setFilter('idle')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    filter === 'idle'
                      ? 'bg-slate-700 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                  }`}
                >
                  Idle ({members.length - activeCount})
                </button>
              </div>

              <button
                onClick={() => navigate('/team')}
                className="text-xs font-bold text-blue-600 hover:text-blue-700"
              >
                All List →
              </button>
            </div>

            {/* Selected Member Detail Banner */}
            {selectedMember && (
              <div className="bg-blue-50 border border-blue-200/80 rounded-2xl p-2.5 mb-2 shrink-0 flex items-center justify-between slide-up">
                <div className="flex items-center gap-2.5">
                  <Avatar name={selectedMember.name} color={selectedMember.avatar_color} size="sm" />
                  <div>
                    <p className="text-xs font-bold text-slate-900">{selectedMember.name}</p>
                    <p className="text-[10px] text-slate-500">{selectedMember.email}</p>
                  </div>
                </div>
                <button
                  onClick={() => navigate(`/team/${selectedMember.id}`)}
                  className="px-3 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-sm hover:bg-blue-700 active:scale-95 transition-all"
                >
                  View Trips
                </button>
              </div>
            )}

            {/* Teammates scroll list */}
            <div className="overflow-y-auto space-y-1.5 flex-1 pr-0.5">
              {filteredMembers.map((member) => {
                const isSelected = member.id === selectedId;
                return (
                  <div
                    key={member.id}
                    onClick={() => setSelectedId(member.id === selectedId ? undefined : member.id)}
                    className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 ${
                      isSelected
                        ? 'bg-blue-50/90 border-blue-300 ring-2 ring-blue-500/20 shadow-sm'
                        : 'bg-white/80 border-slate-100 hover:bg-white'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <Avatar name={member.name} color={member.avatar_color} size="md" />
                      {member.active_status === 'active' && (
                        <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-white tracking-pulse" />
                      )}
                      {member.active_status === 'paused' && (
                        <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-amber-500 rounded-full border-2 border-white" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-slate-900 truncate">{member.name}</p>
                        <span className="text-[10px] font-semibold text-slate-400 font-mono">{member.trip_count} trips</span>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5 text-[11px]">
                        {member.active_status === 'active' ? (
                          <span className="text-green-600 font-bold flex items-center gap-1">
                            <Activity className="w-3 h-3" /> Live Tracking
                          </span>
                        ) : member.active_status === 'paused' ? (
                          <span className="text-amber-600 font-bold flex items-center gap-1">
                            <Activity className="w-3 h-3" /> Paused
                          </span>
                        ) : member.last_seen ? (
                          <span className="text-slate-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {timeAgo(member.last_seen)}
                          </span>
                        ) : (
                          <span className="text-slate-400">No telemetry yet</span>
                        )}
                      </div>
                    </div>

                    <ChevronRight className="w-4 h-4 text-slate-300 shrink-0" />
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: MY LIVE GPS TRIPS CONTENT */}
        {activeTab === 'my-gps' && (
          <div className="flex flex-col flex-1 overflow-y-auto pr-0.5">
            {tracking.isTracking ? (
              <div className="space-y-3">
                {/* Live Telemetry Tiles */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2.5 text-center shadow-sm">
                    <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-0.5">Duration</p>
                    <p className="text-lg font-black text-slate-900 font-mono">{formatDuration(tracking.elapsed)}</p>
                  </div>
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2.5 text-center shadow-sm">
                    <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-0.5">Distance</p>
                    <p className="text-lg font-black text-blue-600 font-mono">{formatDistance(tracking.distance)}</p>
                  </div>
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2.5 text-center shadow-sm">
                    <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-0.5">Speed</p>
                    <p className="text-lg font-black text-slate-900 font-mono">{speedKmh} <span className="text-[9px] font-normal text-slate-500">km/h</span></p>
                  </div>
                </div>

                {/* Tracking Action Controls */}
                <div className="flex gap-2">
                  <button
                    onClick={handlePauseResume}
                    className={`flex-1 py-3 rounded-2xl font-bold text-xs shadow-md flex items-center justify-center gap-1.5 active:scale-95 transition-all ${
                      tracking.isPaused
                        ? 'bg-green-600 hover:bg-green-700 text-white shadow-green-600/30'
                        : 'bg-amber-100 hover:bg-amber-200 text-amber-800'
                    }`}
                  >
                    {tracking.isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5 fill-current" />}
                    {tracking.isPaused ? 'Resume Trip' : 'Pause Trip'}
                  </button>
                  <button
                    onClick={handleStop}
                    className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-bold text-xs shadow-md shadow-red-600/30 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                  >
                    <Square className="w-3.5 h-3.5 fill-current" />
                    Finish Trip
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {/* GPS Status & Start Button */}
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-between">
                  <span className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                    <span className={`w-2.5 h-2.5 rounded-full ${currentLat ? 'bg-green-500 tracking-pulse' : 'bg-amber-400 animate-ping'}`} />
                    {currentLat ? 'Manager GPS Ready' : 'Acquiring GPS Signal...'}
                  </span>
                  {accuracyM !== null && (
                    <span className="text-[10px] text-slate-400 font-medium">±{accuracyM}m accuracy</span>
                  )}
                </div>

                <button
                  onClick={handleStartTracking}
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold rounded-2xl text-sm shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                >
                  <Navigation className="w-4 h-4 fill-current" />
                  Start My GPS Trip
                </button>

                {/* Manager Recent Trips list */}
                {myTrips.length > 0 && (
                  <div className="pt-2">
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">My Recent Trips</p>
                      <button onClick={() => navigate('/history')} className="text-[10px] font-bold text-blue-600 hover:underline">
                        View All Trips →
                      </button>
                    </div>
                    <div className="space-y-1.5">
                      {myTrips.map(t => (
                        <div
                          key={t.id}
                          onClick={() => navigate(`/trips/${t.id}`)}
                          className="bg-white p-2.5 rounded-xl border border-slate-100 flex items-center justify-between cursor-pointer hover:bg-slate-50 transition-colors text-xs"
                        >
                          <div>
                            <p className="font-bold text-slate-800">{new Date(t.started_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
                            <p className="text-[10px] text-slate-400">{formatDuration(t.duration_s || 0)}</p>
                          </div>
                          <span className="font-mono font-bold text-blue-600">{formatDistance(t.distance_m || 0)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

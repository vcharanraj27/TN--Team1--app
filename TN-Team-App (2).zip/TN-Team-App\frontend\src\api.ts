import {
  User,
  Trip,
  Location,
  TeamMember,
  DailyEntry,
  DailyMTD,
  TeamMemberDaily,
  TeamMTD,
  ManagerComment,
  MonthlyTarget,
  TargetWindow,
} from './types';

const BASE = '/api';

async function request<T>(url: string, options: RequestInit = {}, token?: string | null): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(BASE + url, { ...options, headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

export interface TeamOption {
  id: string;
  name: string;
  member_count: number;
}

export const api = {
  auth: {
    login: (email: string, password: string) =>
      request<{ token: string; user: User }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      }),
    register: (data: {
      name: string;
      email: string;
      password: string;
      role: 'manager' | 'member';
      teamId?: string;
      teamName?: string;
      teamPassword?: string;
    }) =>
      request<{ token: string; user: User }>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    teams: () => request<TeamOption[]>('/auth/teams'),
    me: (token: string) => request<User>('/auth/me', {}, token),
    forgotPassword: (email: string) =>
      request<{ success: boolean; message: string; code: string; expiresInMinutes: number }>('/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email }),
      }),
    verifyCode: (email: string, code: string) =>
      request<{ token: string; user: User }>('/auth/verify-code', {
        method: 'POST',
        body: JSON.stringify({ email, code }),
      }),
  },

  trips: {
    list: (token: string, month?: string) =>
      request<Trip[]>(`/trips${month ? `?month=${month}` : ''}`, {}, token),
    get: (token: string, id: string) =>
      request<Trip>(`/trips/${id}`, {}, token),
    locations: (token: string, tripId: string) =>
      request<Location[]>(`/trips/${tripId}/locations`, {}, token),
    start: (token: string, data: { startLat?: number; startLng?: number; startAddress?: string }) =>
      request<Trip>('/trips', { method: 'POST', body: JSON.stringify(data) }, token),
    update: (token: string, id: string, data: object) =>
      request<Trip>(`/trips/${id}`, { method: 'PATCH', body: JSON.stringify(data) }, token),
    delete: (token: string, id: string) =>
      request<{ success: boolean }>(`/trips/${id}`, { method: 'DELETE' }, token),
  },

  locations: {
    post: (token: string, data: object) =>
      request<{ id: string }>('/locations', { method: 'POST', body: JSON.stringify(data) }, token),
    current: (token: string) =>
      request<Location>('/locations/current', {}, token),
    history: (token: string, limit = 50) =>
      request<Location[]>(`/locations/history?limit=${limit}`, {}, token),
    deleteAll: (token: string) =>
      request<{ success: boolean }>('/locations', { method: 'DELETE' }, token),
  },

  daily: {
    get: (token: string, date?: string) =>
      request<DailyEntry>(`/daily${date ? `?date=${date}` : ''}`, {}, token),
    save: (
      token: string,
      data: {
        sales_amount?: number;
        collection_amount?: number;
        activity_count?: number;
        new_pd_count?: number;
        target_sales?: number;
        target_collection?: number;
        target_activity?: number;
        target_new_pd?: number;
        notes?: string;
      }
    ) =>
      request<DailyEntry>('/daily', { method: 'POST', body: JSON.stringify(data) }, token),
    getMonthlyTarget: (token: string, month?: string) =>
      request<{ target: MonthlyTarget | null; targetWindow: TargetWindow }>(
        `/daily/monthly-target${month ? `?month=${month}` : ''}`,
        {},
        token
      ),
    setMonthlyTarget: (
      token: string,
      data: {
        target_sales: number;
        target_collection: number;
        target_activity: number;
        target_new_pd: number;
        month?: string;
      }
    ) =>
      request<{ success: boolean; target: MonthlyTarget; message: string }>(
        '/daily/monthly-target',
        { method: 'POST', body: JSON.stringify(data) },
        token
      ),
    mtd: (token: string) =>
      request<DailyMTD>('/daily/mtd', {}, token),
    comments: (token: string) =>
      request<ManagerComment[]>('/daily/comments', {}, token),
    reply: (token: string, data: { comment: string; entryDate?: string }) =>
      request<ManagerComment>('/daily/reply', { method: 'POST', body: JSON.stringify(data) }, token),
    markRead: (token: string) =>
      request<{ success: boolean }>('/daily/comments/mark-read', { method: 'POST' }, token),
    unreadCount: (token: string) =>
      request<{ count: number }>('/daily/comments/unread-count', {}, token),
    // Manager endpoints
    teamDaily: (token: string, date?: string) =>
      request<TeamMemberDaily[]>(`/daily/team${date ? `?date=${date}` : ''}`, {}, token),
    teamMtd: (token: string) =>
      request<TeamMTD>('/daily/team/mtd', {}, token),
    memberHistory: (token: string, memberId: string) =>
      request<{ member: { id: string; name: string; role?: string }; entries: DailyEntry[]; monthlyTarget: MonthlyTarget | null }>(
        `/daily/team/${memberId}/history`,
        {},
        token
      ),
    postComment: (token: string, data: { memberId: string; comment: string; entryDate?: string }) =>
      request<ManagerComment>('/daily/comment', { method: 'POST', body: JSON.stringify(data) }, token),
    memberComments: (token: string, memberId: string) =>
      request<ManagerComment[]>(`/daily/comments/${memberId}`, {}, token),
    getTargetWindow: (token: string) =>
      request<{ isOpen: boolean; isSubmitted: boolean; canSubmit: boolean; message: string; closesAt: string; date: string }>('/daily/target-window', {}, token),
    getNotifications: (token: string) =>
      request<{ id: string; from_user_id: string; from_user_name: string; type: string; summary: string; is_seen: number; created_at: string }[]>('/daily/notifications', {}, token),
    markNotificationsSeen: (token: string) =>
      request<{ success: boolean }>('/daily/notifications/mark-seen', { method: 'POST' }, token),
  },

  manager: {
    teamInfo: (token: string) =>
      request<{ id: string; name: string; join_password: string; created_at: string }>('/manager/team-info', {}, token),
    updateTeamPassword: (token: string, joinPassword: string) =>
      request<{ success: boolean; joinPassword: string }>('/manager/team-password', {
        method: 'PATCH',
        body: JSON.stringify({ joinPassword }),
      }, token),
    team: (token: string) =>
      request<TeamMember[]>('/manager/team', {}, token),
    member: (token: string, userId: string) =>
      request<TeamMember>(`/manager/team/${userId}`, {}, token),
    memberTrips: (token: string, userId: string, month?: string) =>
      request<Trip[]>(`/manager/team/${userId}/trips${month ? `?month=${month}` : ''}`, {}, token),
    memberTripLocations: (token: string, userId: string, tripId: string) =>
      request<Location[]>(`/manager/team/${userId}/trips/${tripId}/locations`, {}, token),
    memberLocation: (token: string, userId: string) =>
      request<Location>(`/manager/team/${userId}/location`, {}, token),
    deleteMember: (token: string, userId: string) =>
      request<{ success: boolean; message: string; removedUserId: string }>(`/manager/team/${userId}`, { method: 'DELETE' }, token),
  },
};

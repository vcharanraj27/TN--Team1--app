import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { DailyEntry, DailyMTD, ManagerComment, MonthlyTarget, TargetWindow } from '../types';
import {
  IndianRupee,
  TrendingUp,
  Activity,
  Save,
  MessageCircle,
  Calendar,
  CheckCircle2,
  Loader2,
  Bell,
  Send,
  CornerDownRight,
  ShieldCheck,
  User as UserIcon,
  Target,
  Lock,
  Sparkles,
  Award,
  AlertCircle,
  Check,
  Briefcase,
  Layers,
} from 'lucide-react';

export function DailyEntryScreen() {
  const { user, token } = useAuth();

  // Active form section: 'actual' (report today's numbers) or 'target' (set today's target)
  const [entryMode, setEntryMode] = useState<'actual' | 'daily-target'>('actual');

  // Actual Values
  const [sales, setSales] = useState('');
  const [collection, setCollection] = useState('');
  const [activity, setActivity] = useState('');
  const [newPd, setNewPd] = useState('');
  const [notes, setNotes] = useState('');

  // Daily Target Values
  const [targetSales, setTargetSales] = useState('');
  const [targetCollection, setTargetCollection] = useState('');
  const [targetActivity, setTargetActivity] = useState('');
  const [targetNewPd, setTargetNewPd] = useState('');

  // Monthly Target Modal & Values
  const [showMonthlyModal, setShowMonthlyModal] = useState(false);
  const [mTargetSales, setMTargetSales] = useState('');
  const [mTargetCollection, setMTargetCollection] = useState('');
  const [mTargetActivity, setMTargetActivity] = useState('');
  const [mTargetNewPd, setMTargetNewPd] = useState('');
  const [savingMonthlyTarget, setSavingMonthlyTarget] = useState(false);
  const [monthlyTargetError, setMonthlyTargetError] = useState('');

  // Daily target window (10:30 AM IST lock)
  const [dailyTargetWindow, setDailyTargetWindow] = useState<{
    isOpen: boolean;
    isSubmitted: boolean;
    canSubmit: boolean;
    message: string;
  } | null>(null);

  // Save states
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [mtd, setMtd] = useState<DailyMTD | null>(null);
  const [comments, setComments] = useState<ManagerComment[]>([]);
  const [replyText, setReplyText] = useState('');
  const [sendingReply, setSendingReply] = useState(false);
  const [loading, setLoading] = useState(true);

  const commentsEndRef = useRef<HTMLDivElement>(null);

  const today = new Date();
  const dateStr = today.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const monthStr = today.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

  const loadData = useCallback(async () => {
    if (!token) return;
    try {
      setLoading(true);
      const [entry, mtdData, commentsData, targetWindowData] = await Promise.all([
        api.daily.get(token),
        api.daily.mtd(token),
        api.daily.comments(token),
        api.daily.getTargetWindow(token),
      ]);

      // Actuals
      setSales(entry.sales_amount ? String(entry.sales_amount) : '');
      setCollection(entry.collection_amount ? String(entry.collection_amount) : '');
      setActivity(entry.activity_count ? String(entry.activity_count) : '');
      setNewPd(entry.new_pd_count ? String(entry.new_pd_count) : '');
      setNotes(entry.notes || '');

      // Daily Targets
      setTargetSales(entry.target_sales ? String(entry.target_sales) : '');
      setTargetCollection(entry.target_collection ? String(entry.target_collection) : '');
      setTargetActivity(entry.target_activity ? String(entry.target_activity) : '');
      setTargetNewPd(entry.target_new_pd ? String(entry.target_new_pd) : '');

      setMtd(mtdData);
      setComments(commentsData);
      setDailyTargetWindow(targetWindowData);

      // Check for unread manager comments
      const unread = commentsData.filter(c => c.sender_role === 'manager' && c.is_read === 0);
      if (unread.length > 0 && 'Notification' in window && Notification.permission === 'granted') {
        new Notification('TN Team: Manager Comment', {
          body: unread[0].comment,
          icon: '/icon.svg',
        });
      }
    } catch (e) {
      console.error('Failed to load daily data:', e);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    loadData();
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }, [loadData]);

  const handleSaveDaily = async () => {
    if (!token) return;
    setSaving(true);
    try {
      const canSubmitTarget = !dailyTargetWindow || dailyTargetWindow.canSubmit;
      await api.daily.save(token, {
        sales_amount: parseFloat(sales) || 0,
        collection_amount: parseFloat(collection) || 0,
        activity_count: parseInt(activity) || 0,
        new_pd_count: parseInt(newPd) || 0,
        // Only include target fields if the window is open and not yet submitted
        ...(canSubmitTarget && entryMode === 'daily-target' ? {
          target_sales: parseFloat(targetSales) || 0,
          target_collection: parseFloat(targetCollection) || 0,
          target_activity: parseInt(targetActivity) || 0,
          target_new_pd: parseInt(targetNewPd) || 0,
        } : {}),
        notes,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
      const [mtdData, newTargetWindow] = await Promise.all([
        api.daily.mtd(token),
        api.daily.getTargetWindow(token),
      ]);
      setMtd(mtdData);
      setDailyTargetWindow(newTargetWindow);
    } catch (e) {
      console.error('Failed to save daily entry:', e);
    } finally {
      setSaving(false);
    }
  };

  const handleSaveMonthlyTarget = async () => {
    if (!token) return;
    setMonthlyTargetError('');
    setSavingMonthlyTarget(true);
    try {
      await api.daily.setMonthlyTarget(token, {
        target_sales: parseFloat(mTargetSales) || 0,
        target_collection: parseFloat(mTargetCollection) || 0,
        target_activity: parseInt(mTargetActivity) || 0,
        target_new_pd: parseInt(mTargetNewPd) || 0,
      });
      setShowMonthlyModal(false);
      const mtdData = await api.daily.mtd(token);
      setMtd(mtdData);
    } catch (err) {
      setMonthlyTargetError(err instanceof Error ? err.message : 'Failed to save monthly target');
    } finally {
      setSavingMonthlyTarget(false);
    }
  };

  const handleSendReply = async () => {
    if (!token || !replyText.trim()) return;
    setSendingReply(true);
    try {
      const newComment = await api.daily.reply(token, { comment: replyText.trim() });
      setComments(prev => [...prev, newComment]);
      setReplyText('');
      await api.daily.markRead(token);
      setTimeout(() => commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    } catch (e) {
      console.error('Failed to send reply:', e);
    } finally {
      setSendingReply(false);
    }
  };

  const handleMarkAsRead = async () => {
    if (!token) return;
    try {
      await api.daily.markRead(token);
      setComments(prev => prev.map(c => ({ ...c, is_read: 1 })));
    } catch (e) {
      console.error(e);
    }
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(val);
  };

  const calcPercent = (actual: number, target: number) => {
    if (!target || target <= 0) return null;
    return Math.min(Math.round((actual / target) * 100), 999);
  };

  const unreadManagerComments = comments.filter(c => c.sender_role === 'manager' && c.is_read === 0);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gradient-to-b from-blue-50 to-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  const monthlyTarget = mtd?.monthlyTarget;
  const targetWindow = mtd?.targetWindow;

  return (
    <div className="flex-1 overflow-y-auto bg-gradient-to-b from-blue-50 via-white to-slate-50 relative pb-28">
      {/* Header */}
      <div className="px-5 pt-6 pb-2">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Daily Performance</h1>
            <p className="text-xs text-slate-500 mt-0.5">{dateStr}</p>
          </div>
          <span className="px-2.5 py-1 bg-blue-100 text-blue-700 font-bold text-[11px] rounded-full flex items-center gap-1">
            <UserIcon className="w-3.5 h-3.5" /> Teammate
          </span>
        </div>
      </div>

      {/* Unread Manager Feedback Notification Banner */}
      {unreadManagerComments.length > 0 && (
        <div className="mx-5 mb-3 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-3xl p-4 text-white shadow-xl shadow-amber-500/25 animate-pulse">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
              <Bell className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-[11px] font-black uppercase tracking-wider text-amber-100">
                New Comment from Manager ({unreadManagerComments.length})
              </p>
              <p className="text-xs font-semibold mt-0.5 leading-snug line-clamp-2">
                "{unreadManagerComments[unreadManagerComments.length - 1].comment}"
              </p>
              <div className="flex items-center justify-end gap-2 mt-2 pt-2 border-t border-white/20">
                <button onClick={handleMarkAsRead} className="text-[10px] text-amber-100 hover:text-white font-medium">
                  Dismiss
                </button>
                <button
                  onClick={() => {
                    handleMarkAsRead();
                    commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="px-3 py-1 bg-white text-amber-700 font-bold text-xs rounded-xl shadow active:scale-95 transition-transform"
                >
                  View &amp; Reply
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="px-5 space-y-4">
        {/* ==================== MONTHLY TARGET CARD (1st - 7th Lock Rule) ==================== */}
        <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-indigo-400" />
              <div>
                <h2 className="text-xs font-black uppercase tracking-wider text-indigo-200">
                  Monthly Target • {monthStr}
                </h2>
                <p className="text-[10px] text-slate-400">
                  {monthlyTarget ? 'Target locked for this month' : 'Settable once between 1st & 7th'}
                </p>
              </div>
            </div>

            {/* Status Pill */}
            {monthlyTarget ? (
              <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold rounded-full flex items-center gap-1">
                <Lock className="w-3 h-3" /> Locked
              </span>
            ) : targetWindow?.isOpen ? (
              <button
                onClick={() => {
                  setShowMonthlyModal(true);
                  setMonthlyTargetError('');
                }}
                className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[11px] font-bold rounded-xl shadow-lg active:scale-95 transition-transform flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-200" />
                Set Monthly Target
              </button>
            ) : (
              <span className="px-2.5 py-1 bg-red-500/20 text-red-300 border border-red-500/30 text-[10px] font-bold rounded-full flex items-center gap-1">
                <Lock className="w-3 h-3" /> Window Closed
              </span>
            )}
          </div>

          {/* Monthly Target Metrics & Progress */}
          {monthlyTarget ? (
            <div className="space-y-3 mt-3">
              <div className="grid grid-cols-2 gap-2 text-xs">
                {/* Sales Progress */}
                <div className="bg-white/10 rounded-2xl p-2.5 backdrop-blur-sm">
                  <div className="flex justify-between items-center text-[10px] text-indigo-200 mb-1">
                    <span>Sales Target</span>
                    <span className="font-bold text-white">{calcPercent(mtd?.summary.total_sales || 0, monthlyTarget.target_sales)}%</span>
                  </div>
                  <p className="text-sm font-black text-emerald-400">
                    {formatCurrency(mtd?.summary.total_sales || 0)}
                    <span className="text-[10px] text-slate-300 font-normal"> / {formatCurrency(monthlyTarget.target_sales)}</span>
                  </p>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-1.5 overflow-hidden">
                    <div
                      className="bg-emerald-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(calcPercent(mtd?.summary.total_sales || 0, monthlyTarget.target_sales) || 0, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Collection Progress */}
                <div className="bg-white/10 rounded-2xl p-2.5 backdrop-blur-sm">
                  <div className="flex justify-between items-center text-[10px] text-indigo-200 mb-1">
                    <span>Collection Target</span>
                    <span className="font-bold text-white">{calcPercent(mtd?.summary.total_collection || 0, monthlyTarget.target_collection)}%</span>
                  </div>
                  <p className="text-sm font-black text-blue-400">
                    {formatCurrency(mtd?.summary.total_collection || 0)}
                    <span className="text-[10px] text-slate-300 font-normal"> / {formatCurrency(monthlyTarget.target_collection)}</span>
                  </p>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-1.5 overflow-hidden">
                    <div
                      className="bg-blue-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(calcPercent(mtd?.summary.total_collection || 0, monthlyTarget.target_collection) || 0, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Farmer's Visit/Meating Progress */}
                <div className="bg-white/10 rounded-2xl p-2.5 backdrop-blur-sm">
                  <div className="flex justify-between items-center text-[10px] text-indigo-200 mb-1">
                    <span>Farmer's Visit/Meating Target</span>
                    <span className="font-bold text-white">{calcPercent(mtd?.summary.total_activity || 0, monthlyTarget.target_activity)}%</span>
                  </div>
                  <p className="text-sm font-black text-purple-400">
                    {mtd?.summary.total_activity || 0}
                    <span className="text-[10px] text-slate-300 font-normal"> / {monthlyTarget.target_activity}</span>
                  </p>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-1.5 overflow-hidden">
                    <div
                      className="bg-purple-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(calcPercent(mtd?.summary.total_activity || 0, monthlyTarget.target_activity) || 0, 100)}%` }}
                    />
                  </div>
                </div>

                {/* New PD Progress */}
                <div className="bg-white/10 rounded-2xl p-2.5 backdrop-blur-sm">
                  <div className="flex justify-between items-center text-[10px] text-indigo-200 mb-1">
                    <span>New PD Target</span>
                    <span className="font-bold text-white">{calcPercent(mtd?.summary.total_new_pd || 0, monthlyTarget.target_new_pd)}%</span>
                  </div>
                  <p className="text-sm font-black text-amber-400">
                    {mtd?.summary.total_new_pd || 0}
                    <span className="text-[10px] text-slate-300 font-normal"> / {monthlyTarget.target_new_pd}</span>
                  </p>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-1.5 overflow-hidden">
                    <div
                      className="bg-amber-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(calcPercent(mtd?.summary.total_new_pd || 0, monthlyTarget.target_new_pd) || 0, 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="mt-2 text-xs text-slate-300 bg-white/5 p-3 rounded-2xl border border-white/10">
              {targetWindow?.isOpen ? (
                <p className="flex items-center gap-1.5 text-amber-300 font-medium">
                  <Sparkles className="w-4 h-4 shrink-0" />
                  Target setting window is open! You have {targetWindow.daysRemaining} day(s) left to set your monthly targets for {monthStr}.
                </p>
              ) : (
                <p className="flex items-center gap-1.5 text-slate-400">
                  <AlertCircle className="w-4 h-4 shrink-0 text-slate-500" />
                  Monthly target window opens on the 1st of every month (runs 1st to 7th).
                </p>
              )}
            </div>
          )}
        </div>

        {/* ==================== TODAY'S ENTRY FORM: ACTUALS & DAILY TARGETS ==================== */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Today's Report</h2>
            {/* Toggle Actuals vs Daily Target */}
            <div className="flex bg-slate-100 p-0.5 rounded-xl text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setEntryMode('actual')}
                className={`px-3 py-1 rounded-lg transition-all ${
                  entryMode === 'actual' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500'
                }`}
              >
                Actuals
              </button>
              <button
                type="button"
                onClick={() => setEntryMode('daily-target')}
                className={`px-3 py-1 rounded-lg transition-all ${
                  entryMode === 'daily-target' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500'
                }`}
              >
                Daily Target
              </button>
            </div>
          </div>

          {entryMode === 'actual' ? (
            /* ACTUALS INPUTS */
            <div className="space-y-3.5">
              {/* Day Sales */}
              <div>
                <label className="text-xs font-semibold text-slate-700 mb-1 block">Day Sales Amount (₹)</label>
                <div className="relative">
                  <IndianRupee className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                  <input
                    type="number"
                    value={sales}
                    onChange={e => setSales(e.target.value)}
                    placeholder="0"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Collection */}
              <div>
                <label className="text-xs font-semibold text-slate-700 mb-1 block">Collection Amount (₹)</label>
                <div className="relative">
                  <IndianRupee className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-500" />
                  <input
                    type="number"
                    value={collection}
                    onChange={e => setCollection(e.target.value)}
                    placeholder="0"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Grid for Farmer's Visit/Meating & New PD */}
              <div className="grid grid-cols-2 gap-3">
                {/* Farmer's Visit/Meating */}
                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">Farmer's Visit/Meating</label>
                  <div className="relative">
                    <Activity className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-500" />
                    <input
                      type="number"
                      value={activity}
                      onChange={e => setActivity(e.target.value)}
                      placeholder="0"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* New PD */}
                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">New PD (Count)</label>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-500" />
                    <input
                      type="number"
                      value={newPd}
                      onChange={e => setNewPd(e.target.value)}
                      placeholder="0"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-semibold text-slate-700 mb-1 block">Notes / Remarks</label>
                <textarea
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Notes, client feedback, visited areas..."
                  rows={2}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>
            </div>
          ) : (
            /* DAILY TARGET INPUTS — locked after 10:30 AM or if already submitted */
            <div className="space-y-3.5">
              {/* Lock Status Banner */}
              {dailyTargetWindow && !dailyTargetWindow.canSubmit ? (
                <div className={`p-4 rounded-2xl flex items-start gap-3 ${
                  dailyTargetWindow.isSubmitted
                    ? 'bg-emerald-50 border border-emerald-200'
                    : 'bg-red-50 border border-red-200'
                }`}>
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                    dailyTargetWindow.isSubmitted ? 'bg-emerald-100' : 'bg-red-100'
                  }`}>
                    {dailyTargetWindow.isSubmitted
                      ? <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      : <Lock className="w-4 h-4 text-red-500" />
                    }
                  </div>
                  <div>
                    <p className={`text-xs font-bold mb-0.5 ${
                      dailyTargetWindow.isSubmitted ? 'text-emerald-800' : 'text-red-700'
                    }`}>
                      {dailyTargetWindow.isSubmitted ? '✅ Daily Target Submitted' : '🔒 Entry Window Closed'}
                    </p>
                    <p className={`text-[11px] ${
                      dailyTargetWindow.isSubmitted ? 'text-emerald-700' : 'text-red-600'
                    }`}>
                      {dailyTargetWindow.message}
                    </p>
                    {!dailyTargetWindow.isSubmitted && (
                      <p className="text-[10px] text-slate-500 mt-1">Daily targets can only be set before 10:30 AM IST</p>
                    )}
                  </div>
                </div>
              ) : (
                <p className="text-xs font-bold text-indigo-900 flex items-center gap-1 mb-1 bg-indigo-50/50 p-3 rounded-2xl border border-indigo-100">
                  <Target className="w-3.5 h-3.5 text-indigo-600" /> Set Today's Daily Target
                  <span className="ml-auto text-[10px] text-indigo-500 font-normal">Locks at 10:30 AM IST</span>
                </p>
              )}

              {/* Show inputs only if canSubmit */}
              {(!dailyTargetWindow || dailyTargetWindow.canSubmit) && (
                <>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 mb-1 block">Daily Sales Target (₹)</label>
                    <input
                      type="number"
                      value={targetSales}
                      onChange={e => setTargetSales(e.target.value)}
                      placeholder="e.g. 10000"
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 mb-1 block">Daily Collection Target (₹)</label>
                    <input
                      type="number"
                      value={targetCollection}
                      onChange={e => setTargetCollection(e.target.value)}
                      placeholder="e.g. 5000"
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 mb-1 block">Farmer's Visit/Meating Target</label>
                      <input
                        type="number"
                        value={targetActivity}
                        onChange={e => setTargetActivity(e.target.value)}
                        placeholder="e.g. 8"
                        className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 mb-1 block">New PD Target</label>
                      <input
                        type="number"
                        value={targetNewPd}
                        onChange={e => setTargetNewPd(e.target.value)}
                        placeholder="e.g. 2"
                        className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Save Button */}
          <button
            onClick={handleSaveDaily}
            disabled={saving}
            className={`w-full mt-4 py-3.5 rounded-2xl font-bold text-white text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] ${
              saved
                ? 'bg-emerald-600'
                : 'bg-gradient-to-r from-blue-600 to-blue-500 shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40'
            }`}
          >
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : saved ? (
              <><CheckCircle2 className="w-4 h-4" /> Saved Successfully!</>
            ) : (
              <><Save className="w-4 h-4" /> Save Today's Report</>
            )}
          </button>
        </div>


        {/* ==================== MONTHLY HISTORY ==================== */}

        {mtd && mtd.dailyHistory.length > 0 && (
          <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
            <h2 className="text-sm font-bold text-slate-800 mb-3 uppercase tracking-wider">This Month's Submissions</h2>
            <div className="space-y-2">
              {mtd.dailyHistory.map((entry) => (
                <div key={entry.entry_date} className="flex items-center justify-between py-2.5 px-3.5 bg-slate-50 rounded-2xl">
                  <span className="text-xs font-semibold text-slate-700">
                    {new Date(entry.entry_date + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}
                  </span>
                  <div className="flex gap-2 text-xs font-bold">
                    <span className="text-emerald-600">{formatCurrency(entry.sales_amount)}</span>
                    <span className="text-blue-600">{formatCurrency(entry.collection_amount)}</span>
                    <span className="text-purple-600">{entry.activity_count} FV</span>
                    <span className="text-amber-600">{entry.new_pd_count} PD</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================== MANAGER FEEDBACK & TWO-WAY REPLIES ==================== */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-amber-500" />
              Manager Feedback &amp; Discussion
            </h2>
            {comments.length > 0 && (
              <span className="text-[11px] text-slate-400 font-medium">{comments.length} messages</span>
            )}
          </div>

          {/* Conversation Thread */}
          <div className="space-y-3 mb-4 max-h-72 overflow-y-auto pr-1">
            {comments.length === 0 ? (
              <div className="bg-slate-50 p-4 rounded-2xl text-center">
                <MessageCircle className="w-8 h-8 text-slate-300 mx-auto mb-1.5" />
                <p className="text-xs text-slate-400 font-medium">No feedback or comments from your manager yet.</p>
              </div>
            ) : (
              comments.map((c) => {
                const isFromManager = c.sender_role === 'manager';
                return (
                  <div key={c.id} className={`flex flex-col ${isFromManager ? 'items-start' : 'items-end'}`}>
                    <div
                      className={`max-w-[85%] rounded-2xl p-3 shadow-sm ${
                        isFromManager
                          ? 'bg-amber-50 border border-amber-200 text-slate-900 rounded-tl-sm'
                          : 'bg-blue-600 text-white rounded-tr-sm'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1 text-[10px] font-bold">
                        {isFromManager ? (
                          <>
                            <ShieldCheck className="w-3 h-3 text-amber-700" />
                            <span className="text-amber-800 font-bold">{c.sender_name || 'Manager'}</span>
                          </>
                        ) : (
                          <>
                            <UserIcon className="w-3 h-3 text-blue-200" />
                            <span className="text-blue-100">You (Reply)</span>
                          </>
                        )}
                      </div>
                      <p className="text-xs leading-relaxed">{c.comment}</p>
                      <p className={`text-[9px] mt-1 text-right ${isFromManager ? 'text-amber-700/70' : 'text-blue-200'}`}>
                        {new Date(c.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}{' '}
                        •{' '}
                        {new Date(c.created_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={commentsEndRef} />
          </div>

          {/* Reply Input Box */}
          <div className="pt-2 border-t border-slate-100">
            <p className="text-[11px] font-semibold text-slate-600 mb-1.5 flex items-center gap-1">
              <CornerDownRight className="w-3 h-3 text-blue-500" />
              Reply to Manager
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                value={replyText}
                onChange={e => setReplyText(e.target.value)}
                placeholder="Type your reply to manager..."
                className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                onKeyDown={e => e.key === 'Enter' && handleSendReply()}
              />
              <button
                type="button"
                onClick={handleSendReply}
                disabled={sendingReply || !replyText.trim()}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl active:scale-95 disabled:opacity-40 transition-all flex items-center gap-1.5 shadow-md shadow-blue-500/20"
              >
                {sendingReply ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ==================== SET MONTHLY TARGET MODAL (1st to 7th only) ==================== */}
      {showMonthlyModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Set Monthly Target</h3>
                  <p className="text-[10px] text-slate-400">{monthStr} (Lockable 1st - 7th)</p>
                </div>
              </div>
              <button
                onClick={() => setShowMonthlyModal(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-2.5 my-3 leading-snug">
              ⚠️ <strong>Important:</strong> Monthly target can only be set <strong>once per month between the 1st and 7th</strong>. Once saved, it is locked.
            </p>

            {monthlyTargetError && (
              <div className="p-2.5 mb-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-medium">
                {monthlyTargetError}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 mb-1 block">Monthly Sales Target (₹)</label>
                <input
                  type="number"
                  value={mTargetSales}
                  onChange={e => setMTargetSales(e.target.value)}
                  placeholder="e.g. 200000"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 mb-1 block">Monthly Collection Target (₹)</label>
                <input
                  type="number"
                  value={mTargetCollection}
                  onChange={e => setMTargetCollection(e.target.value)}
                  placeholder="e.g. 150000"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">Farmer's Visit/Meating Target</label>
                  <input
                    type="number"
                    value={mTargetActivity}
                    onChange={e => setMTargetActivity(e.target.value)}
                    placeholder="e.g. 150"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">New PD Target</label>
                  <input
                    type="number"
                    value={mTargetNewPd}
                    onChange={e => setMTargetNewPd(e.target.value)}
                    placeholder="e.g. 30"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-2 mt-4 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowMonthlyModal(false)}
                className="flex-1 py-2.5 bg-slate-100 text-slate-700 font-bold rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveMonthlyTarget}
                disabled={savingMonthlyTarget}
                className="flex-1 py-2.5 bg-indigo-600 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1 shadow-md active:scale-95 disabled:opacity-50"
              >
                {savingMonthlyTarget ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                Confirm &amp; Lock
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

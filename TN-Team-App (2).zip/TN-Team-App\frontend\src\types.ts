// Shared TypeScript types for the GPS Tracker app

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'manager' | 'member';
  teamId: string;
  teamName: string;
  avatarColor: string;
  teamJoinPassword?: string;
}

export interface Trip {
  id: string;
  user_id: string;
  team_id: string;
  status: 'active' | 'paused' | 'completed';
  distance_m: number;
  duration_s: number;
  start_address: string | null;
  end_address: string | null;
  start_lat: number | null;
  start_lng: number | null;
  end_lat: number | null;
  end_lng: number | null;
  started_at: string;
  ended_at: string | null;
  paused_at: string | null;
  location_count?: number;
}

export interface Location {
  id: string;
  lat: number;
  lng: number;
  accuracy: number | null;
  speed: number | null;
  heading: number | null;
  altitude: number | null;
  timestamp: string;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'manager' | 'member';
  avatar_color: string;
  last_lat: number | null;
  last_lng: number | null;
  last_seen: string | null;
  trip_count: number;
  active_status: 'active' | 'paused' | null;
}

export interface TrackingState {
  isTracking: boolean;
  isPaused: boolean;
  tripId: string | null;
  startTime: number | null;
  distance: number;
  currentLat: number | null;
  currentLng: number | null;
}

export interface DailyEntry {
  id?: string;
  user_id?: string;
  team_id?: string;
  entry_date: string;
  sales_amount: number;
  collection_amount: number;
  activity_count: number;
  new_pd_count: number;
  target_sales: number;
  target_collection: number;
  target_activity: number;
  target_new_pd: number;
  notes?: string;
  updated_at?: string;
}

export interface MonthlyTarget {
  id?: string;
  user_id?: string;
  team_id?: string;
  target_month: string;
  target_sales: number;
  target_collection: number;
  target_activity: number;
  target_new_pd: number;
  is_locked?: number;
  set_at?: string;
  created_at?: string;
}

export interface TargetWindow {
  isOpen: boolean;
  dayOfMonth: number;
  daysRemaining: number;
  currentMonth: string;
  isSet: boolean;
  canSet: boolean;
  windowMessage: string;
}

export interface DailyMTD {
  summary: {
    total_sales: number;
    total_collection: number;
    total_activity: number;
    total_new_pd: number;
    total_target_sales: number;
    total_target_collection: number;
    total_target_activity: number;
    total_target_new_pd: number;
    days_entered: number;
  };
  monthlyTarget: MonthlyTarget | null;
  targetWindow: TargetWindow;
  dailyHistory: DailyEntry[];
  monthStart: string;
  today: string;
}

export interface TeamMemberDaily {
  id: string;
  name: string;
  email: string;
  role?: 'manager' | 'member';
  avatar_color: string;
  sales_amount: number;
  collection_amount: number;
  activity_count: number;
  new_pd_count: number;
  target_sales: number;
  target_collection: number;
  target_activity: number;
  target_new_pd: number;
  notes?: string;
  updated_at?: string;
  entry_date?: string;
  monthly_target_sales?: number;
  monthly_target_collection?: number;
  monthly_target_activity?: number;
  monthly_target_new_pd?: number;
}

export interface TeamMTD {
  memberTotals: {
    id: string;
    name: string;
    role?: 'manager' | 'member';
    avatar_color: string;
    total_sales: number;
    total_collection: number;
    total_activity: number;
    total_new_pd: number;
    total_target_sales: number;
    total_target_collection: number;
    total_target_activity: number;
    total_target_new_pd: number;
    days_entered: number;
    monthly_target_sales?: number;
    monthly_target_collection?: number;
    monthly_target_activity?: number;
    monthly_target_new_pd?: number;
  }[];
  teamTotal: {
    total_sales: number;
    total_collection: number;
    total_activity: number;
    total_new_pd: number;
    total_target_sales: number;
    total_target_collection: number;
    total_target_activity: number;
    total_target_new_pd: number;
  };
  teamMonthlyTarget?: {
    target_sales: number;
    target_collection: number;
    target_activity: number;
    target_new_pd: number;
  } | null;
  monthStart: string;
  today: string;
}

export interface ManagerComment {
  id: string;
  comment: string;
  entry_date?: string;
  created_at: string;
  manager_name?: string;
  sender_id?: string;
  sender_name?: string;
  sender_role?: 'manager' | 'member';
  is_read?: number;
}

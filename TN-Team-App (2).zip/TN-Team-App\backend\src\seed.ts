/**
 * Seed script — creates sample data.
 * Run: npx ts-node src/seed.ts
 */
import { initDb, dbRun, dbAll, closeDb } from './database';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

function randomBetween(a: number, b: number): number {
  return a + Math.random() * (b - a);
}

function addSeconds(date: Date, s: number): Date {
  return new Date(date.getTime() + s * 1000);
}

function formatISO(d: Date): string {
  return d.toISOString().replace('T', ' ').replace(/\.\d+Z$/, '');
}

const BASE_LAT = 51.505;
const BASE_LNG = -0.09;

interface RoutePoint { lat: number; lng: number; }

function generateRoute(startLat: number, startLng: number, points: number): RoutePoint[] {
  const route: RoutePoint[] = [{ lat: startLat, lng: startLng }];
  let lat = startLat, lng = startLng;
  for (let i = 1; i < points; i++) {
    lat += randomBetween(-0.002, 0.002);
    lng += randomBetween(-0.002, 0.002);
    route.push({ lat, lng });
  }
  return route;
}

function haversineDistance(a: RoutePoint, b: RoutePoint): number {
  const R = 6371000;
  const φ1 = (a.lat * Math.PI) / 180;
  const φ2 = (b.lat * Math.PI) / 180;
  const Δφ = ((b.lat - a.lat) * Math.PI) / 180;
  const Δλ = ((b.lng - a.lng) * Math.PI) / 180;
  const aa = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1 - aa));
}

const ADDRESSES = [
  'Tower Bridge Rd, London SE1', 'Oxford Street, London W1', 'Canary Wharf, London E14',
  'Greenwich High Rd, London SE10', 'Westfield Stratford City, London E20',
  'Victoria Station, London SW1V', 'Liverpool Street, London EC2M',
  'Shoreditch High St, London E1', "King's Cross, London N1C",
  'Waterloo Station, London SE1', 'Brixton Market, London SW9',
  'Hackney Central, London E8', 'Clapham Junction, London SW11',
  'Elephant & Castle, London SE1', 'Paddington Station, London W2',
  'Hammersmith, London W6', 'Islington, London N1', 'Camden Town, London NW1',
  'Notting Hill, London W11', 'Bethnal Green, London E2',
];

const AVATAR_COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#14b8a6',
  '#3b82f6', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16', '#f59e0b',
];

const TEAM_MEMBERS = [
  { name: 'Sarah Chen',       email: 'sarah.chen@apexlogistics.com',      role: 'manager' as const },
  { name: 'James Okafor',     email: 'james.okafor@apexlogistics.com',     role: 'member' as const },
  { name: 'Priya Sharma',     email: 'priya.sharma@apexlogistics.com',     role: 'member' as const },
  { name: 'Marcus Webb',      email: 'marcus.webb@apexlogistics.com',      role: 'member' as const },
  { name: 'Aisha Patel',      email: 'aisha.patel@apexlogistics.com',      role: 'member' as const },
  { name: 'Tom Nguyen',       email: 'tom.nguyen@apexlogistics.com',       role: 'member' as const },
  { name: 'Elena Rodriguez',  email: 'elena.rodriguez@apexlogistics.com',  role: 'member' as const },
  { name: 'David Kim',        email: 'david.kim@apexlogistics.com',        role: 'member' as const },
  { name: 'Fatima Al-Hassan', email: 'fatima.alhassan@apexlogistics.com',  role: 'member' as const },
  { name: 'Ryan Clarke',      email: 'ryan.clarke@apexlogistics.com',      role: 'member' as const },
  { name: 'Mei Lin',          email: 'mei.lin@apexlogistics.com',          role: 'member' as const },
];

async function seed() {
  console.log('🌱 Seeding database...');
  await initDb();

  // Wipe existing data
  dbRun('DELETE FROM locations');
  dbRun('DELETE FROM trips');
  dbRun('DELETE FROM users');
  dbRun('DELETE FROM teams');

  // Create team
  const teamId = uuidv4();
  dbRun(`INSERT INTO teams (id, name) VALUES (?, ?)`, [teamId, 'Apex Logistics']);
  console.log(`✅ Team: Apex Logistics`);

  // Create users
  const passwordHash = await bcrypt.hash('password123', 10);
  const userIds: string[] = [];

  for (let i = 0; i < TEAM_MEMBERS.length; i++) {
    const m = TEAM_MEMBERS[i];
    const id = uuidv4();
    userIds.push(id);
    dbRun(
      `INSERT INTO users (id, team_id, name, email, password_hash, role, avatar_color) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, teamId, m.name, m.email, passwordHash, m.role, AVATAR_COLORS[i % AVATAR_COLORS.length]]
    );
    console.log(`  ${m.role === 'manager' ? '👔' : '🧑'} ${m.name} — ${m.email}`);
  }

  // Generate trips + locations (3 months of history)
  const now = new Date();

  for (let u = 0; u < userIds.length; u++) {
    const userId = userIds[u];
    let totalTrips = 0;

    for (let monthOffset = 0; monthOffset < 3; monthOffset++) {
      const tripsThisMonth = Math.floor(randomBetween(8, 18));
      for (let t = 0; t < tripsThisMonth; t++) {
        const daysBack = monthOffset * 30 + Math.floor(randomBetween(0, 28));
        const tripStart = new Date(now.getTime() - daysBack * 24 * 3600 * 1000);
        tripStart.setHours(Math.floor(randomBetween(7, 18)), Math.floor(randomBetween(0, 59)), 0, 0);

        const numPoints = Math.floor(randomBetween(10, 40));
        const startLat = BASE_LAT + randomBetween(-0.08, 0.08);
        const startLng = BASE_LNG + randomBetween(-0.12, 0.12);
        const route = generateRoute(startLat, startLng, numPoints);

        let totalDist = 0;
        for (let i = 1; i < route.length; i++) totalDist += haversineDistance(route[i - 1], route[i]);

        const durationS = Math.floor(totalDist / randomBetween(5, 15));
        const tripEnd = addSeconds(tripStart, durationS);
        const tripId = uuidv4();
        const startAddr = ADDRESSES[Math.floor(Math.random() * ADDRESSES.length)];
        const endAddr = ADDRESSES[Math.floor(Math.random() * ADDRESSES.length)];
        const endPoint = route[route.length - 1];

        dbRun(
          `INSERT INTO trips (id, user_id, team_id, status, distance_m, duration_s, start_address, end_address,
           start_lat, start_lng, end_lat, end_lng, started_at, ended_at)
           VALUES (?, ?, ?, 'completed', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [tripId, userId, teamId, Math.round(totalDist), durationS,
           startAddr, endAddr, route[0].lat, route[0].lng, endPoint.lat, endPoint.lng,
           formatISO(tripStart), formatISO(tripEnd)]
        );

        const timePerPoint = durationS / numPoints;
        for (let p = 0; p < route.length; p++) {
          const ts = addSeconds(tripStart, p * timePerPoint);
          dbRun(
            `INSERT INTO locations (id, user_id, trip_id, team_id, lat, lng, accuracy, speed, is_tracking, timestamp)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
            [uuidv4(), userId, tripId, teamId,
             route[p].lat, route[p].lng,
             Math.floor(randomBetween(3, 15)), randomBetween(2, 14),
             formatISO(ts)]
          );
        }
        totalTrips++;
      }
    }

    // Current location ping
    dbRun(
      `INSERT INTO locations (id, user_id, trip_id, team_id, lat, lng, accuracy, speed, is_tracking, timestamp)
       VALUES (?, ?, NULL, ?, ?, ?, 8, 0, 0, datetime('now'))`,
      [uuidv4(), userId, teamId,
       BASE_LAT + randomBetween(-0.05, 0.05),
       BASE_LNG + randomBetween(-0.08, 0.08)]
    );

    console.log(`  📍 ${TEAM_MEMBERS[u].name}: ${totalTrips} trips`);
  }

  closeDb();

  console.log('\n✅ Seed complete!\n');
  console.log('📋 Login credentials (password: password123)');
  console.log('─'.repeat(60));
  for (const m of TEAM_MEMBERS) {
    console.log(`  ${m.role === 'manager' ? '👔 Manager' : '🧑 Member '} │ ${m.email}`);
  }
  console.log('─'.repeat(60));
}

seed().catch(console.error);

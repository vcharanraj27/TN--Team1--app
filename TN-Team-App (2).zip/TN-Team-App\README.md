# TN Team — Mobile-First GPS Location, Targets & Team Operations Platform

A production-ready, full-stack mobile-first platform featuring real-time GPS telemetry, daily & monthly targets, two-way feedback, audio notifications, manager administration, and durable data persistence.

---

## 📱 Key Features & Modules

1. **Daily Report & Target System**:
   - **4 Core Metrics**: Sales (₹), Collection (₹), Farmer's Visit/Meating, New PD.
   - **Today Report Layout**: Side-by-side comparison with **Daily Target** on the left and **Actual** on the right.
   - **10:30 AM IST Daily Target Lock**: Teammates can enter daily targets only once per day before 10:30 AM IST. After 10:30 AM, target entry locks automatically.
   - **Monthly Targets**: Target setting allowed once per month between the 1st and 7th of every month.

2. **Manager Radar & In-Place GPS Trips**:
   - **Team Radar**: Interactive team map showing all teammates with avatar pins, live tracking badges, and active/idle filters.
   - **My Live GPS Trips**: Embedded directly below the map with Start Trip, Pause, Resume, Stop, Speed (km/h), Distance, Duration, and recent trips list.

3. **Sound Alerts & Notifications**:
   - Audio chime and browser push notifications for managers whenever a teammate submits or updates an entry.
   - Automatic deduplication prevents duplicate notifications for the same entry.
   - Dynamic badge counters on the Daily tab.

4. **Teammate Administration**:
   - Managers can remove teammates with a confirmation dialog from both the Teammate Profile and Team List screens.
   - Deletion removes user records, trips, locations, and daily logs.

5. **Durable Storage & Reliability**:
   - **Atomic Disk Writes**: Avoids database corruption during abrupt power loss or reboots.
   - **Automated Rolling Backups**: Automatic snapshot created on startup and rolling backups every 4 hours (retaining the latest 10 snapshots in `backend/data/backups/`).
   - **Crash Protection**: Signal hooks (`SIGINT`, `SIGTERM`, `beforeExit`, `uncaughtException`, `unhandledRejection`) guarantee disk flushing before process exit.
   - **Network-First Service Worker**: Eliminates stale cache and white-screen issues on mobile devices.
   - **React Error Boundary**: User-friendly fallback screen with Reload and Session Reset controls.

---

## 🚀 How to Run the App

### Option A: One-Click Windows Runner
Double-click `start-app.bat` in the project root to start the production server on `http://localhost:4000`.

### Option B: Manual Command Line
```bash
# 1. Install dependencies
cd backend && npm install
cd ../frontend && npm install

# 2. Build frontend
cd ../frontend && npm run build

# 3. Start server
cd ../backend
npx ts-node src/index.ts
```

The application runs on `http://localhost:4000` (serving both API endpoints and the compiled frontend static app).

---

## 💾 Backup & Restoration Guide

### How to Create a Backup
1. **Via Browser / API**: Navigate to `http://localhost:4000/api/backup` (or via your public tunnel URL) to download the latest timestamped `.db` snapshot.
2. **Via Script (Windows)**: Double-click `backup-data.bat` to save an instant snapshot to `backend/data/backups/`.
3. **Manual Copy**: Copy `backend/data/tracker.db` to a safe location.

### How to Restore from a Backup
1. **Via Script (Windows)**: Double-click `restore-data.bat` and select the backup file you want to restore.
2. **Manual Restore**:
   - Stop the backend server.
   - Copy your chosen backup file (e.g., `backend/data/backups/tracker-startup-xxx.db`) and rename it to `backend/data/tracker.db`.
   - Start the backend server (`start-app.bat` or `npx ts-node src/index.ts`).

---

## 🌐 Hosting & Public Access Options

| Hosting Approach | URL Stability | Setup Required | Ongoing Cost | Recommended Use |
| :--- | :--- | :--- | :--- | :--- |
| **1. Cloudflare Quick Tunnel** *(Current Active Setup)* | Ephemeral (URL changes on reconnect) | None (`cloudflared.exe tunnel --url http://127.0.0.1:4000`) | **$0 / Free** | Immediate day-to-day testing and mobile installation |
| **2. Cloudflare Named Tunnel** | **Permanent fixed URL** (e.g. `team.yourdomain.com`) | Free Cloudflare account + custom domain | Domain (~$10/yr), Tunnel is **Free** | Recommended for permanent production team use |
| **3. Cloud VPS / Container (Render, Railway, Fly.io, AWS)** | **Permanent fixed URL** | Deploy repository via Docker or Node.js runtime | Free tiers available; ~$5-$10/mo for dedicated hosting | 24/7 standalone cloud hosting without local PC running |

---

## 📲 How Users Install the App on Mobile Phones

### **Android (Google Chrome)**:
1. Open the public app URL in Chrome.
2. Tap the **three-dots menu (`⋮`)** at the top right.
3. Tap **"Install app"** or **"Add to Home screen"**.

### **iPhone / iOS (Safari)**:
1. Open the public app URL in Safari.
2. Tap the **Share icon** (square with an upward arrow).
3. Tap **"Add to Home Screen"** and tap **Add**.

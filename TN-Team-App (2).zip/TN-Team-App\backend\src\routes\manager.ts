import { Router, Request, Response } from 'express';
import { dbAll, dbGet, dbRun, QueryParam } from '../database';
import { authenticate, requireManager } from '../middleware/auth';

const router = Router();
router.use(authenticate, requireManager);

// GET /api/manager/team-info — get team info and join password
router.get('/team-info', (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const team = dbGet<{ id: string; name: string; join_password: string; created_at: string }>(
    `SELECT id, name, join_password, created_at FROM teams WHERE id = ?`,
    [teamId]
  );
  if (!team) { res.status(404).json({ error: 'Team not found' }); return; }
  res.json(team);
});

// PATCH /api/manager/team-password — update team join password
router.patch('/team-password', (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const { joinPassword } = req.body;

  if (!joinPassword || !joinPassword.trim()) {
    res.status(400).json({ error: 'Join password cannot be empty' });
    return;
  }

  dbRun(`UPDATE teams SET join_password = ? WHERE id = ?`, [joinPassword.trim(), teamId]);
  res.json({ success: true, joinPassword: joinPassword.trim() });
});

// GET /api/manager/team
router.get('/team', (req: Request, res: Response) => {
  const { teamId } = req.user!;

  const members = dbAll(
    `SELECT u.id, u.name, u.email, u.role, u.avatar_color,
            l.lat as last_lat, l.lng as last_lng, l.timestamp as last_seen,
            (SELECT COUNT(*) FROM trips t WHERE t.user_id = u.id AND t.team_id = ?) as trip_count,
            (SELECT status FROM trips t2 WHERE t2.user_id = u.id AND t2.team_id = ? AND (t2.status = 'active' OR t2.status = 'paused') LIMIT 1) as active_status
     FROM users u
     LEFT JOIN locations l ON l.id = (
       SELECT id FROM locations WHERE user_id = u.id AND team_id = ? ORDER BY timestamp DESC LIMIT 1
     )
     WHERE u.team_id = ?
     ORDER BY u.name`,
    [teamId, teamId, teamId, teamId]
  );

  res.json(members);
});

// GET /api/manager/team/:userId
router.get('/team/:userId', (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const targetUserId = String(req.params.userId);

  const member = dbGet(
    `SELECT u.id, u.name, u.email, u.role, u.avatar_color,
            l.lat as last_lat, l.lng as last_lng, l.timestamp as last_seen
     FROM users u
     LEFT JOIN locations l ON l.id = (
       SELECT id FROM locations WHERE user_id = u.id AND team_id = ? ORDER BY timestamp DESC LIMIT 1
     )
     WHERE u.id = ? AND u.team_id = ?`,
    [teamId, targetUserId, teamId]
  );

  if (!member) { res.status(404).json({ error: 'Team member not found' }); return; }
  res.json(member);
});

// GET /api/manager/team/:userId/trips?month=2024-10
router.get('/team/:userId/trips', (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const targetUserId = String(req.params.userId);
  const { month } = req.query;

  const member = dbGet(
    `SELECT id FROM users WHERE id = ? AND team_id = ?`,
    [targetUserId, teamId]
  );
  if (!member) { res.status(404).json({ error: 'Team member not found' }); return; }

  let query = `SELECT * FROM trips WHERE user_id = ? AND team_id = ?`;
  const params: QueryParam[] = [targetUserId, teamId];

  if (month && typeof month === 'string') {
    query += ` AND strftime('%Y-%m', started_at) = ?`;
    params.push(month);
  }

  query += ` ORDER BY started_at DESC LIMIT 100`;
  const trips = dbAll(query, params);
  res.json(trips);
});

// GET /api/manager/team/:userId/trips/:tripId/locations
router.get('/team/:userId/trips/:tripId/locations', (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const targetUserId = String(req.params.userId);
  const tripId = String(req.params.tripId);

  const member = dbGet(`SELECT id FROM users WHERE id = ? AND team_id = ?`, [targetUserId, teamId]);
  if (!member) { res.status(404).json({ error: 'Team member not found' }); return; }

  const trip = dbGet(
    `SELECT id FROM trips WHERE id = ? AND user_id = ? AND team_id = ?`,
    [tripId, targetUserId, teamId]
  );
  if (!trip) { res.status(404).json({ error: 'Trip not found' }); return; }

  const locations = dbAll(
    `SELECT id, lat, lng, accuracy, speed, heading, altitude, timestamp
     FROM locations WHERE trip_id = ? AND user_id = ? AND team_id = ? ORDER BY timestamp ASC`,
    [tripId, targetUserId, teamId]
  );
  res.json(locations);
});

// GET /api/manager/team/:userId/location
router.get('/team/:userId/location', (req: Request, res: Response) => {
  const { teamId } = req.user!;
  const targetUserId = String(req.params.userId);

  const member = dbGet(`SELECT id FROM users WHERE id = ? AND team_id = ?`, [targetUserId, teamId]);
  if (!member) { res.status(404).json({ error: 'Team member not found' }); return; }

  const location = dbGet(
    `SELECT id, lat, lng, accuracy, speed, heading, timestamp
     FROM locations WHERE user_id = ? AND team_id = ? ORDER BY timestamp DESC LIMIT 1`,
    [targetUserId, teamId]
  );
  if (!location) { res.status(404).json({ error: 'No location data for this member' }); return; }
  res.json(location);
});

// DELETE /api/manager/team/:userId — Manager removes a teammate
router.delete('/team/:userId', (req: Request, res: Response) => {
  const { teamId, userId: managerId } = req.user!;
  const targetUserId = String(req.params.userId);

  if (targetUserId === managerId) {
    res.status(400).json({ error: 'You cannot remove yourself as a manager from the team.' });
    return;
  }

  const member = dbGet<{ id: string; name: string; role: string }>(
    `SELECT id, name, role FROM users WHERE id = ? AND team_id = ?`,
    [targetUserId, teamId]
  );

  if (!member) {
    res.status(404).json({ error: 'Teammate not found or does not belong to your team.' });
    return;
  }

  if (member.role === 'manager') {
    res.status(403).json({ error: 'Cannot remove another manager.' });
    return;
  }

  // Clean up teammate data from all tables
  try {
    dbRun(`DELETE FROM locations WHERE user_id = ?`, [targetUserId]);
    dbRun(`DELETE FROM trips WHERE user_id = ?`, [targetUserId]);
    dbRun(`DELETE FROM daily_entries WHERE user_id = ?`, [targetUserId]);
    dbRun(`DELETE FROM monthly_targets WHERE user_id = ?`, [targetUserId]);
    dbRun(`DELETE FROM manager_comments WHERE member_id = ? OR sender_id = ?`, [targetUserId, targetUserId]);
    dbRun(`DELETE FROM notifications WHERE from_user_id = ?`, [targetUserId]);
    dbRun(`DELETE FROM users WHERE id = ? AND team_id = ?`, [targetUserId, teamId]);

    res.json({
      success: true,
      message: `Teammate "${member.name}" has been removed from the team.`,
      removedUserId: targetUserId,
    });
  } catch (err) {
    console.error('Failed to delete teammate:', err);
    res.status(500).json({ error: 'Failed to remove teammate from database.' });
  }
});

export { router as managerRouter };

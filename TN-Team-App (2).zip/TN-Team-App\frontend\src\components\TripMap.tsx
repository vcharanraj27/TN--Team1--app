import { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Location } from '../types';

interface TripMapProps {
  locations: Location[];
  center?: [number, number];
  className?: string;
  showMarkers?: boolean;
}

export function TripMap({ locations, center, className = '', showMarkers = true }: TripMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current) return;

    // Init map
    const map = L.map(mapRef.current, {
      zoomControl: true,
      attributionControl: false,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
    }).addTo(map);

    if (locations.length > 0) {
      const coords = locations.map(l => [l.lat, l.lng] as [number, number]);

      // Draw route polyline
      L.polyline(coords, {
        color: '#2563eb',
        weight: 4,
        opacity: 0.85,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);

      if (showMarkers) {
        // Start marker
        const startIcon = L.divIcon({
          className: '',
          html: `<div style="background:#22c55e;width:14px;height:14px;border-radius:50%;border:3px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3)"></div>`,
          iconAnchor: [7, 7],
        });
        L.marker(coords[0], { icon: startIcon }).addTo(map)
          .bindTooltip('Start', { permanent: false });

        // End marker
        const endIcon = L.divIcon({
          className: '',
          html: `<div style="background:#ef4444;width:14px;height:14px;border-radius:50%;border:3px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3)"></div>`,
          iconAnchor: [7, 7],
        });
        L.marker(coords[coords.length - 1], { icon: endIcon }).addTo(map)
          .bindTooltip('End', { permanent: false });
      }

      // Fit bounds
      map.fitBounds(L.latLngBounds(coords), { padding: [20, 20] });
    } else if (center) {
      map.setView(center, 14);
    } else {
      map.setView([51.505, -0.09], 13);
    }

    leafletMap.current = map;

    return () => {
      map.remove();
      leafletMap.current = null;
    };
  }, []);

  // Update route when locations change
  useEffect(() => {
    const map = leafletMap.current;
    if (!map || locations.length === 0) return;

    const coords = locations.map(l => [l.lat, l.lng] as [number, number]);
    map.eachLayer(layer => {
      if (layer instanceof L.Polyline && !(layer instanceof L.Polygon)) {
        map.removeLayer(layer);
      }
    });
    L.polyline(coords, { color: '#2563eb', weight: 4, opacity: 0.85 }).addTo(map);
    map.fitBounds(L.latLngBounds(coords), { padding: [20, 20] });
  }, [locations]);

  return <div ref={mapRef} className={`w-full ${className}`} style={{ minHeight: 200 }} />;
}

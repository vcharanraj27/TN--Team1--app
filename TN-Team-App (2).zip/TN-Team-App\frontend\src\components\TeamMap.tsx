import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Location, TeamMember } from '../types';
import { getInitials } from '../utils';

interface LiveLocation {
  member: TeamMember;
  location: Location | null;
}

interface TeamMapProps {
  members: LiveLocation[];
  selectedMemberId?: string;
  onMemberClick?: (member: TeamMember) => void;
  className?: string;
  myLat?: number;
  myLng?: number;
}

export function TeamMap({ members, selectedMemberId, onMemberClick, className = '', myLat, myLng }: TeamMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<L.Map | null>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());

  useEffect(() => {
    if (!mapRef.current) return;

    const map = L.map(mapRef.current, { zoomControl: true, attributionControl: false });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18 }).addTo(map);

    // Default London view
    map.setView([51.505, -0.09], 12);
    leafletMap.current = map;

    return () => {
      markersRef.current.clear();
      map.remove();
      leafletMap.current = null;
    };
  }, []);

  // Update markers when members change
  useEffect(() => {
    const map = leafletMap.current;
    if (!map) return;

    const validLocations: [number, number][] = [];

    // Remove stale markers
    markersRef.current.forEach((marker, id) => {
      if (!members.find(m => m.member.id === id)) {
        map.removeLayer(marker);
        markersRef.current.delete(id);
      }
    });

    // Add / update member markers
    members.forEach(({ member, location }) => {
      if (!location) return;
      validLocations.push([location.lat, location.lng]);

      const isSelected = member.id === selectedMemberId;
      const isActive = member.active_status === 'active';

      const html = `
        <div style="
          background: ${member.avatar_color};
          width: ${isSelected ? 40 : 32}px;
          height: ${isSelected ? 40 : 32}px;
          border-radius: 50%;
          border: ${isSelected ? 4 : 3}px solid white;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3)${isSelected ? ', 0 0 0 3px ' + member.avatar_color + '66' : ''};
          display: flex; align-items: center; justify-content: center;
          font-size: ${isSelected ? 13 : 11}px;
          font-weight: 700; color: white;
          font-family: Inter, sans-serif;
          transition: all 0.2s;
          cursor: pointer;
          position: relative;
        ">
          ${getInitials(member.name)}
          ${isActive ? `<div style="position:absolute;top:-2px;right:-2px;width:10px;height:10px;background:#22c55e;border-radius:50%;border:2px solid white;"></div>` : ''}
        </div>
      `;

      const icon = L.divIcon({ className: '', html, iconAnchor: [isSelected ? 20 : 16, isSelected ? 20 : 16] });

      if (markersRef.current.has(member.id)) {
        const m = markersRef.current.get(member.id)!;
        m.setLatLng([location.lat, location.lng]);
        m.setIcon(icon);
      } else {
        const m = L.marker([location.lat, location.lng], { icon })
          .addTo(map)
          .bindTooltip(member.name, { permanent: false, direction: 'top', offset: [0, -8] });
        if (onMemberClick) m.on('click', () => onMemberClick(member));
        markersRef.current.set(member.id, m);
      }
    });

    // My location marker
    if (myLat !== undefined && myLng !== undefined) {
      validLocations.push([myLat, myLng]);
    }

    // Fit to all markers
    if (selectedMemberId) {
      const mem = members.find(m => m.member.id === selectedMemberId);
      if (mem?.location) {
        map.setView([mem.location.lat, mem.location.lng], 15, { animate: true });
      }
    } else if (validLocations.length > 0) {
      map.fitBounds(L.latLngBounds(validLocations), { padding: [30, 30], maxZoom: 14 });
    }
  }, [members, selectedMemberId]);

  return <div ref={mapRef} className={`w-full ${className}`} style={{ minHeight: 300 }} />;
}
